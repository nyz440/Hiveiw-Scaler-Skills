---
name: grhx-6315ac-onboarding
description: '本技能是 GRHX 6315AC 监控 SOC（HT6315A / HT6315C）SDK 的新手代码阅读与架构学习知识库。当用户需要理解该项目的目录结构、分层架构（Boot / Vos / Driver / MiddleWare / user）、启动到 main 再到主循环的执行流程、消息队列与状态机机制、Flash 存储与寿命测算，或导入新主板并对照电路设定 PIN 脚、导入新屏参并按规格书设定时序与接口、修改 EDID（HDMI/DP/VGA 字节表、校验和、默认表与 Flash/量产烧录）、以及询问"从哪里开始读这套代码""某个模块怎么读""改需求应该改哪里"时触发。This skill should be used when the user is onboarding to, reading, or navigating the GRHX 6315AC monitor SOC SDK, porting a new board or panel, configuring GPIO pin mux or panel timing parameters, editing EDID tables or checksums, or asks where/how to start reading the codebase, how a module works, or where to implement a change.'
---

# GRHX 6315AC SDK 新手学习指南

## 用途
把这套裸机前后台（nonos superloop）监控 SOC SDK 的阅读方法、架构逻辑、关键机制固化为可复用知识，
让新人快速建立全局认知、知道"先看哪、再看哪、最后看哪"，并能在遇到 Flash / 存储 / 模块定位 / 板级适配问题时直接查到答案。

## 何时使用
- 新人接手项目，问"怎么看这套代码 / 从哪入手"
- 需要理解 `main → SystemManager → Vos → Driver → user` 的调用链与分层职责
- 涉及 Flash 存储次数 / 寿命、脏标记、磨损均衡等问题
- 导入一块新主板，需要对照硬件电路设定 PIN 脚、配置引脚复用（PinMux）
- 导入一块新屏参，需要按屏规格书设定时序、接口、上下电延时并选中生效
- 修改 EDID：字节表、CheckSum、默认 EDID 与 Flash/EEPROM 量产烧录、HPD 重读
- 需要定位某个功能（OSD、通道、电源、驱动寄存器）应该读哪些文件
- 解释 `HV_CONFIG_ON/OFF` 宏开关、`hv_` 命名规则等工程约定

## 如何使用（专题索引，按需加载 references/）
- `references/architecture.md` — 分层架构、目录职责、启动→main→主循环、消息队列/状态机机制（必读基础）
- `references/code-reading-path.md` — 新手看代码 8 步路线图（按此顺序读最省力）
- `references/flash-storage.md` — Flash 存储机制（脏标记/追加写/磨损均衡）+ 寿命测算模型与场景表
- `references/cheatsheet.md` — 一页纸速查：关键文件、宏开关、`hv_` 命名规则、常用入口函数
- `references/topics/_template.md` — 新增专题的复制模板
- `references/topics/osd-menu.md` — [扩展中] OSD 菜单数据流
- `references/topics/driver-register.md` — [扩展中] 驱动寄存器操作（HV_R32 / HV_W32）
- `references/topics/power-channel-manager.md` — [扩展中] 电源 / 通道管理器
- `references/topics/board-porting.md` — [已梳理] 新主板 PIN 脚适配：BoardConfig 脚号映射 + Pinshare 复用
- `references/topics/panel-porting.md` — [已梳理] 导入新屏参：GR_PanelConfig.h 参数、编译期 -include 选中、静态/动态屏参
- `references/topics/edid-porting.md` — [已梳理] EDID 修改：TBL_EDID_* 字节表、CheckSum、默认表 vs Flash/量产烧录、HPD

## 扩展机制（"先有再优"）
本知识库设计为可成长结构：每深入一个模块，复制 `references/topics/_template.md` 改名填写，
并在上方索引表追加一行即可。智能体下次遇到相关问题会自动加载对应专题。
