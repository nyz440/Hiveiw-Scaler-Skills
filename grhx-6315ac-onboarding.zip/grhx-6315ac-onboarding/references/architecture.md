# 架构：分层、目录职责与运行流程

> 本文档建立全局认知。读完它，你应清楚"代码分几层、每层干什么、程序怎么跑起来、事件怎么流动"。

## 1. 这是什么项目
- **监控 SOC（Scaler，图像处理主控）嵌入式软件**，芯片 `HT6315A` / `HT6315C`。
- 原厂 SDK 来自 **HiView Software**（代码前缀 `hv_`），`GRHX` 是客户 / 整机厂商定制层。
- **裸机 nonos 前后台架构**：没有 RTOS，只有一个 `main()` 大循环，用"消息队列 + 状态机"模拟多任务。
- 工程语言：纯 C，通过宏开关（`HV_CONFIG_ON/OFF`）裁剪功能。

## 2. 整体分层（依赖自上而下）

```
GRHX_6315AC_Series/
├── build/          构建系统（Makefile、配置脚本、编译规则 .inc）
├── prebuilds/      原厂预编译库（libpq.a、libHdcpCal.a …），只给 .a 不给源码
├── sdk/            原厂 SDK（框架主体）
│   ├── Boot/       启动代码（汇编.S + C）：上电最先跑，设栈/中断/时钟，跳 main
│   ├── Common/     公共组件（Assert、Debug、Event、Timer、Util…）
│   ├── Driver/     外设驱动（Peripheral、DisplayCtrl、HDMI、DPU、PLL、PMU、OSD…）
│   ├── MiddleWare/ 中间件 / 业务调度（含 main.c 与 RunTime 任务）
│   ├── Vos/        虚拟 OS 抽象层（Queue / Task / Timer / Semaphore / Memory / Log）
│   └── Loader/ PQlib/  引导、图像画质库
└── user/           客户定制层
    ├── Comm/       跨项目公共配置（DDCCI、EDID、Factory、Panel、Board）
    └── GRHX/       具体机型（HT6315A_DEMO_1A1H、HT6315C_DEMO_1D1H）
```

**依赖方向**：`user → MiddleWare → Driver → Vos`；`Boot → MiddleWare`；公共组件 `Common → Vos`。
记忆口诀：**Boot 起来 → 调 main → MiddleWare 用 Vos 提供的队列/定时器驱动 Driver，客户差异都在 user/。**

## 3. 各层职责速记
| 层 | 角色 | 代表文件 |
|---|---|---|
| Boot | 上电初始化，设栈/中断向量/时钟，跳 `main` | `sdk/Boot/Chip/*.S`、`sdk/Boot/Common` |
| Vos | "操作系统"抽象：队列、定时器、任务、内存、日志 | `sdk/Vos/inc/hv_vos_Queue.h`、`hv_vos_Timer.h`、`hv_vos_Task.h` |
| Driver | 寄存器级外设操作（Key/ADC/LED/PMU/Flash/Display…） | `sdk/Driver/Peripheral/drv/src/hv_drv_*.c` |
| MiddleWare | 业务调度核心，含 `main.c` 与 RunTime 任务 | `sdk/MiddleWare/main.c`、`RunTime/SystemTask` |
| user | 机型定制：OSD、DataBase、ProjectConfig、Panel、Keypad… | `user/GRHX/HT6315A_DEMO_1A1H/*` |

## 4. 程序执行流程

### 4.1 配置与编译（运行前）
- `build/project_config.sh [vendor] [project] [chip] [boottype] [platform]`：生成 `out/.config`，
  定义 `CONFIG_VENDOR / CONFIG_PROJECT / CONFIG_CHIP` 等变量，后续 `build/Makefile` 靠它们拼路径。
- 顶层 `Makefile` 仅两行，真正逻辑在 `build/Makefile`：`PRE_CHECK`（配置校验、拷贝预编译 .a）
  → 进入 `build_out` 执行 `Makefile.mk` → 各层编成静态库（`libvos.a`、`libdriver.a`、`libmiddleware.a`…）
  → 链接成 `Monitor_SOC.bin`。

### 4.2 运行（板子上电）
- `Boot/` 汇编初始化栈、中断向量、时钟，最后跳进 `main()`。
- `main()`（见 `sdk/MiddleWare/main.c`）是系统心脏：

```text
main():
  Hv_Mw_System_Init();                  // 初始化所有硬件/软件模块
  Hv_Mw_System_AllMessageQueueCreate();  // 给各模块建消息队列
  Hv_Mw_System_TaskStartInit();         // 系统任务初始化（含 Database 同步定时器）
  Hv_Mw_EventHub_TaskStartInit();       // 事件中心初始化
  Hv_Mw_Osd_TaskStartInit();            // OSD 任务初始化
  Hv_Vos_EnableIrq();                   // 开中断
  while (1) {                           // 超级循环
      Hv_Vos_Timer_Update();            // 更新软件定时器
      Hv_Mw_Urgent_TaskHandle();        // 紧急任务（最高优先级）
      Hv_Mw_System_TaskHandle();        // 系统任务：EventDispatch 分发各队列
      Hv_Mw_EventHubTaskHandle();       // 事件中心
      Hv_Debug_ShellTaskHandle();       // Debug Shell（仅 debug 版本）
      Hv_User_PlatformHandle();         // 用户平台处理（若开启）
  }
```

### 4.3 核心设计逻辑（务必理解）
1. **"任务"是状态机函数，不是多线程**：`SystemTask/OsdTask/UrgentTask` 并非 RTOS 线程，
   而是 `while(1)` 里**顺序调用**的函数。`Vos` 的 `Task` 更多是接口兼容。
2. **消息队列驱动的"事件分发"**：`Hv_Mw_System_Init()` 初始化各模块并建队列；
   `Hv_Mw_System_TaskHandle()` 调 `EventDispatch()`，按序从 Power/Channel/InputPort/Panel/OSD 等队列
   取消息交给对应模块的 `ProcXXXQueueMsg` 状态机处理。这是**生产者-消费者 + 前后台**模型。
3. **Urgent 抢占**：`EventDispatch` 每处理一个队列前都检查 `Hv_Mw_Urgent_GetUrgentEventFlag()`，
   紧急事件（按键、断电）置位时立即 `return` 让出，下一轮先跑 `Urgent_TaskHandle()`。即裸机下的"优先级抢占"。
4. **Database 是全局数据中心**：所有模块通过 `HV_COMMON_DATABASE_GET/SET` 读写用户数据，
   由周期定时器统一同步到 Flash/EEPROM（详见 `references/flash-storage.md`）。

## 5. 启动→主循环流程图

```mermaid
flowchart LR
    A[Boot 汇编: 栈/中断/时钟] --> B["main()"]
    B --> C["System_Init 初始化所有模块"]
    C --> D["创建各模块消息队列"]
    D --> E["各任务 TaskStartInit"]
    E --> F["EnableIrq 开中断"]
    F --> G{"while(1) 超级循环"}
    G --> H[Timer_Update]
    H --> I[Urgent 任务]
    I --> J[System 任务 EventDispatch]
    J --> K[EventHub 任务]
    K --> L[OSD / Shell / User]
    L --> G
```
