# 新手看代码路线图（按此顺序最省力）

> 不要一上来就全局搜索、大海捞针。按下面 8 步，由外到内、由骨架到细节。

| 步骤 | 看什么 | 目的 / 关键文件 |
|---|---|---|
| **1** | 工程配置入口 | `build/project_config.sh`、`user/GRHX/HT6315A_DEMO_1A1H/ProjectConfig.h` —— 搞懂"一个工程怎么被配置出来"（芯片/项目/宏开关） |
| **2** | 程序入口 | `sdk/MiddleWare/main.c` —— 建立"入口 + 主循环"骨架认知 |
| **3** | 系统初始化与事件分发 | `sdk/MiddleWare/RunTime/SystemTask/src/hv_mw_SystemManager.c` —— 看 `Hv_Mw_System_Init()` 初始化顺序、`EventDispatch()` 事件分发（见 `references/architecture.md` 第 4 节） |
| **4** | OS 抽象层 | `sdk/Vos/inc/hv_vos_Queue.h`、`hv_vos_Timer.h`、`hv_vos_Task.h` —— 理解框架给业务提供的"基础设施"（队列/定时器/任务抽象） |
| **5** | 挑一个业务模块深入 | `sdk/MiddleWare/ChannelManager/` 或 `InputPortManager/` —— 看 `ProcXXXQueueMsg` 状态机如何处理具体业务 |
| **6** | 驱动层 | `sdk/Driver/Peripheral/`、`sdk/Driver/DisplayCtrl/` —— 看驱动如何用 `HV_R32/HV_W32` 操作寄存器读写硬件 |
| **7** | 三大任务协作 | `sdk/MiddleWare/RunTime/UrgentTask/`、`OsdTask/`、`EventHub` —— 补全 Urgent/OSD/EventHub 的协作逻辑 |
| **8** | 客户定制层 | `user/GRHX/HT6315A_DEMO_1A1H/` 下的 `OSD/`、`DataBase/`、`BackLight/`、`ProjectConfig/` —— 看客户如何"填空"（实际改需求最多在这层） |

## 关键心法
- **找函数别靠猜，用"跳转到定义"**：全工程函数按 `Hv_<层>_<模块>_<动作>` 命名
  （如 `Hv_Mw_Channel_Manager_Init`），从名字就能定位文件。
- **前缀区分归属**：`hv_` = HiView 原厂；`GR_` / `GRHX` / `USER_` = 客户定制，改需求优先在 `user/` 找。
- **宏开关决定代码是否编译**：看不懂某功能是否开启，搜 `HV_PROJECT_CONFIG_xxx` 宏（多集中在 `ProjectConfig.h` 与 `user/Comm/ProjectConfig_Default_HT6315A.h`）。
- **存储/寿命问题**：直接查 `references/flash-storage.md`。
- **想深入某模块**：先看 `references/topics/` 下是否已有专题，没有就按 `_template.md` 建一个。
