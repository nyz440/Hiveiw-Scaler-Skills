# Flash 存储机制与寿命测算

> 本文档回答两个问题：(1) 当前代码怎么把数据存进 Flash；(2) Flash 会被写多少次、能用多久。
> 所有参数均从代码实证，非推测。

## 1. 存储机制（代码实证）

### 1.1 同步由 5 秒定时器驱动，但靠脏标记节流
- `SystemManager.c` 建一个周期 **5000ms** 的软件定时器（`DATABASE_PERIOD_SYNC_GLOBAL_TO_FLASH_TIMER_LENGTH = 5000`），
  超时后通过 Channel 队列投递 `SYS_EVENT_TIMER_DATABASE_SYNC_TIMER`，`EventDispatch` 收到后调用 `Hv_Common_Database_Sync()`。
- 该周期**强制 < 喂狗时间（10000ms）**（代码里有编译期 `#error` 校验）。

### 1.2 脏标记 `bModifyFlag` —— 没改动就完全不写 Flash
每个数据区（User/System/TimeRec/Factory/Hdcp/Gamma）的 Sync 函数开头都有拦截：
```c
if (HV_FALSE == HV_COMMON_DATABASE_GET(UserData, bModifyFlag)) return HV_SUCCESS; // 没改动直接返回，0 次 Flash 操作
```
`bModifyFlag` 由写宏 `HV_COMMON_DATABASE_SET` 在**值真正变化**（memcmp 不等）时才置位，不是每次赋值都置。

### 1.3 写入策略：追加写 + 整扇区擦除（自带磨损均衡）
核心在 `Hv_Common_Database_MonitorData_Save()`（`user/GRHX/.../DataBase/OSD_xxx/src/hv_comm_DataBase.c`）：
```c
uiBlkSize = ALLIGNUP16(uiDataSize);   // 每条记录按 16 字节对齐
uiBlkNum  = SECTOR_SIZE / uiBlkSize;  // 一个 4KB 扇区能放几条
// 在扇区内找"全 0xFFFFFFFF"的空白块 → 直接追加写，不擦除
// 若扇区写满(uiBlkLoop == uiBlkNum) → Hv_Drv_Flash_OnlyErase(整扇区) 后才从头写
Hv_Drv_Flash_OnlyWrite(uiTempAdr, pucData, uiDataSize);
```
硬件参数：`SECTOR_SIZE = 4*1024`（4KB）。

### 1.4 顶层 Sync 顺序（每区独立脏标记）
`Hv_Common_Database_Sync()` 依次调：`SyncUser → SyncSystem → SyncTimeRec → SyncFactory → SyncHdcp → SyncGamma`，各区独立判断是否需写。

## 2. 寿命测算模型
设：
- 某数据区大小（16 字节对齐后）为 `B` 字节；
- 单扇区可容纳记录数 `K = floor(4096 / B)`；
- 该区**每天真实写入次数** = `f`（= 每天 `bModifyFlag` 被触发且落盘的次数）；
- Flash 标称擦写寿命 `P`（SPI NOR 典型 **10 万次**，需查具体型号 datasheet）。

则：
- 每天擦除次数 = `f / K`（追加写不擦除，只有写满一个扇区才擦 1 次，被 `K` 倍摊销）
- 该区可支撑天数 = `P × K / f`

> 关键：**擦除次数 ≪ 写入次数**，且 `f` 在无改动时为 0。这是该设计对 Flash 友好之处。

## 3. 当前代码的真实写入源与频率（实测）
| 写入源 | 触发条件 | 频率 | 备注 |
|---|---|---|---|
| **TimeRec**（面板开机计时） | `HV_PROJECT_CONFIG_FACTORY_PANEL_TIME_COUNT_PERIOD` | **每 30 分钟 1 次**（默认 30，合法 10~60） | `hv_mw_CommFactory.c`，稳定的"心跳"写入 |
| **User 区**（亮度/对比度/通道/OSD…） | 用户每次改参数 | 因人而异（每天几次~几十次） | 主要消耗源 |
| System/Factory/Hdcp/Gamma | 仅特定事件（首次无 magic、出厂复位、标定） | 极少 | 非持续源 |
| 5 秒轮询本身 | 定时器超时 | 每 5 秒调用 Sync | **无改动时 0 Flash 操作** |

> `HV_PROJECT_CONFIG_USERDATA_BACKUP` 若开启，User 区写两份（主+备），**擦写翻倍**（仅影响 User 区）。

## 4. 寿命测算场景表（以 User 区为例，假设 B≈512 → K≈8，P=10 万次）
| 场景 | 每日写入 f | 每日擦除 f/K | 可支撑 |
|---|---|---|---|
| 正常使用（每天改 ~20 次） | 20 | 2.5 | ≈ **109 年** ✅ |
| 重度使用（每天改 200 次） | 200 | 25 | ≈ **11 年** ✅ |
| TimeRec 心跳（每 30 分钟，且区很小 K 更大） | 48 | <1 | **百年级** ✅ |
| 最坏持续写（每 5 秒都改，f=17280/天） | 17280 | 2160 | ≈ **46 天** ⚠️ 仅理论极限 |

## 5. 结论与待确认参数
- 设计**合理稳健**：脏标记 + 追加写 + 4KB 扇区磨损均衡，把擦除寿命放大 `K` 倍。正常/重度使用均为"年~百年"级，不构成风险。
- 唯一理论风险是"每 5 秒持续改写"的极端场景（约 1.5 个月），不属于正常使用。
- **精度取决于 3 个参数**（替换上面公式即可精算）：
  1. `sizeof(UserDataDBRegion)` 实际字节数（决定 `K`，见各 OSD 的 `hv_comm_DataBase.h` 结构体定义）；
  2. Flash 芯片型号标称 P/E 寿命 `P`（SPI NOR 常见 10 万次）；
  3. `HV_PROJECT_CONFIG_USERDATA_BACKUP` 是否开启（翻倍）。
