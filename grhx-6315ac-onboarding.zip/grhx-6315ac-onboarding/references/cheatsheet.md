# 一页纸速查表

## 1. 关键文件（按阅读优先级）
| 作用 | 路径 |
|---|---|
| 程序入口 / 主循环 | `sdk/MiddleWare/main.c` |
| 系统初始化 + 事件分发 | `sdk/MiddleWare/RunTime/SystemTask/src/hv_mw_SystemManager.c` |
| 工程配置（芯片/项目/宏） | `user/GRHX/HT6315A_DEMO_1A1H/ProjectConfig.h`、`user/Comm/ProjectConfig_Default_HT6315A.h` |
| 配置脚本（生成 .config） | `build/project_config.sh`、`build/Makefile` |
| OS 抽象：队列/定时器/任务/内存 | `sdk/Vos/inc/hv_vos_{Queue,Timer,Task,Memory,Log}.h` |
| 全局数据 + Flash 存储逻辑 | `user/GRHX/.../DataBase/OSD_xxx/src/hv_comm_DataBase.c`、`inc/hv_comm_DataBase.h` |
| Flash 驱动 | `sdk/Driver/Peripheral/drv/src/hv_drv_Flash.c` |
| 面板开机计时（TimeRec） | `user/Comm/Factory/src/hv_mw_CommFactory.c` |
| 业务模块（通道/输入口/面板/电源） | `sdk/MiddleWare/{ChannelManager,InputPortManager,PanelManager,PowerManager}/` |
| 客户机型定制根 | `user/GRHX/HT6315A_DEMO_1A1H/{OSD,DataBase,BackLight,Keypad,Led,System,ProjectConfig}/` |

## 2. 宏开关约定
- `HV_CONFIG_ON = 1` / `HV_CONFIG_OFF = 0`：功能裁剪总开关。
- `HV_PROJECT_CONFIG_xxx`：项目级配置（看门狗、Flash 存储类型、TimeRec 周期、备份等），
  多集中在 `ProjectConfig.h` 与各 `PROJECT_*.h`，缺省值见 `user/Comm/ProjectConfig_Default_HT6315x.h`。
- 编译期校验示例：`DATABASE_PERIOD_SYNC_GLOBAL_TO_FLASH_TIMER_LENGTH` 必须 `< HV_PROJECT_CONFIG_FEED_WATCHDOG_TIME`（否则 `#error`）。

## 3. 函数命名规则（`Hv_<层>_<模块>_<动作>`）
| 前缀 | 含义 | 例 |
|---|---|---|
| `Hv_Mw_` | MiddleWare 中间件/业务 | `Hv_Mw_System_Init`、`Hv_Mw_Channel_Manager_Init` |
| `Hv_Drv_` | Driver 驱动层 | `Hv_Drv_Flash_WriteMonitorData`、`Hv_Drv_Key_Init` |
| `Hv_Vos_` | Vos OS 抽象层 | `Hv_Vos_QueueInit`、`Hv_Vos_Timer_Create` |
| `Hv_Comm_` | Common 公共组件 | `Hv_Common_Database_Sync` |
| `hv_`（头文件） | HiView 原厂头 | `hv_comm_DataBase.h` |
| `GR_` / `GRHX` / `USER_` | 客户定制 | `GR_CUSTOM_PROJECT`、用户层目录 |

## 4. 常用入口函数（跳转锚点）
- 初始化总入口：`Hv_Mw_System_Init()`（`SystemManager.c`）
- 主循环任务：`Hv_Mw_System_TaskHandle()` → `EventDispatch()`
- 数据库同步：`Hv_Common_Database_Sync()`（5s 定时器触发）
- 数据读写：`HV_COMMON_DATABASE_GET(module, param)` / `HV_COMMON_DATABASE_SET(module, param, value)`
- 寄存器操作：`HV_R32(addr)` / `HV_W32(addr, val)`（驱动层用）
- 临界区：`Intr_IntrDisable()` / `Intr_IntrRestore()`

## 5. 一眼看懂的架构口诀
**Boot 起来 → 调 main → MiddleWare 用 Vos 提供的队列/定时器驱动 Driver，客户差异都在 user/。**
**裸机前后台 = 一个 while(1) 超级循环 + 各模块消息队列 + 状态机；Urgent 事件可抢占。**
