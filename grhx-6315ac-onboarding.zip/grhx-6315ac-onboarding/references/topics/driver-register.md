# 专题：驱动寄存器操作（扩展中）

> 定位：Driver 层如何用 `HV_R32 / HV_W32` 读写芯片寄存器，以及临界区与初始化顺序。

## 1. 涉及的关键文件（待补充完整路径）
- `sdk/Driver/Peripheral/drv/src/hv_drv_*.c` — 各外设驱动（Key/ADC/LED/PMU/Flash…）
- `sdk/Driver/Peripheral/drv/inc/hv_drv_*.h` — 驱动接口与寄存器宏
- `sdk/Driver/Arch/<chip>/*.h` — 芯片寄存器地址定义（`ht6315a/` 或 `ht6315c/`）

## 2. 核心概念 / 数据流（待填）
- 寄存器读写：`HV_R32(addr)` 读 32 位，`HV_W32(addr, val)` 写 32 位（见 `sdk/Vos/inc/hv_vos_*`）。
- 临界区：写关键硬件前用 `Intr_IntrDisable()` / `Intr_IntrRestore()` 关中断保护。
- 初始化顺序：由 `Hv_Mw_System_Init()` 统一编排（PLL → PHY → Flash → Key → EEPROM → …）。

## 3. 关键函数入口（待填）
| 函数名 | 文件 | 作用 |
|--------|------|------|
| `Hv_Drv_Flash_WriteMonitorData` | hv_drv_Flash.c | 写 Flash（自动擦除对应地址） |
| `Hv_Drv_Key_Init` | hv_drv_Key.c | 按键初始化 |

## 4. 常见坑点 / 注意（待填）
- 不同芯片（`ht6315a` vs `ht6315c`）寄存器定义分目录，切换项目注意 Arch 路径。
- Flash 写前需整扇区擦除（见 `references/flash-storage.md` 的磨损均衡机制）。

## 5. 关联专题
- 相关：`[[osd-menu]]`、`[[power-channel-manager]]`
