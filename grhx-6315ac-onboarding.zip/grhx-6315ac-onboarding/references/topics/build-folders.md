# 专题：编译包含哪些文件夹（Build Folders）

> 定位：回答「从 `build.sh` 到 `make` 结束，哪些目录的源文件真正编进固件」。
> 是理解分层架构（`architecture.md`）之后、动手读某个模块之前的"地图"，
> 也是**精简代码库 / 新增机型工程 / 排查编译报错**时的必查专题。

## 1. 涉及的关键文件

| 文件 | 职责 |
|---|---|
| `user/GRHX/<机型>/build.sh` | 入口：提取 `GR_*` 变量 → 生成配置 → `make` → 打包 bin |
| `build/project_config.sh`、`build/common_config.sh` | 生成 `out/.config`（芯片 / 机型 / 型号） |
| `build/Makefile` | 定义全部路径变量、`CONFIG_*_LIB` 库清单、`PRE_CHECK`、debug/release 目标 |
| `build/compile/common.inc` | 编译环境：`-D` 宏、10 条 `-include`、编译规则、优化选项 |
| `build/compile/{sdk,user}_targets.inc` | 仅转发 include 到 `sdk/Makefile.mk` / `user/Makefile.mk` |
| `build/compile/prebuilds.inc`、`tool_targets.inc` | **未生效**（`build/Makefile:69` 注释；后者全仓无 include） |
| `sdk/Makefile.mk`、`user/Makefile.mk` | 递归调度各子目录 `Makefile.mk`，产出静态库 |
| 各目录 `Makefile.mk` | 用 `wildcard` 收集本目录 `.c`/`.S`，配合 `VPATH` 编译成 `.o` |
| `build/Makefile.mk` | 最终链接：`sdk/MiddleWare/main.c` + `LIB_STATIC` → `Monitor_SOC.bin` |

## 2. 核心机制：三条独立路径 + 三个变量

### 2.1 编译主链路（mermaid）

```mermaid
flowchart TD
    A["build.sh\ngrep 提取 GR_* 变量并 export"] --> B["project_config.sh\n生成 out/.config"]
    B --> C["make clean"]
    C --> D["make release|debug -j"]
    D --> E["PRE_CHECK\n编译 AllConfigCheck.c (触发 #error 校验)\ncp prebuilds/&lt;chip&gt;/*.a"]
    E --> F["sdk/Makefile.mk + user/Makefile.mk\n递归调用子 Makefile.mk，wildcard 收 .c/.S"]
    F --> G["ar 打包 11 个 lib*.a"]
    G --> H["build/Makefile.mk\nsdk/MiddleWare/main.c + LIB_STATIC → elf/map/bin"]
    H --> I["build.sh 回到打包\n合并 PQ/LOGO/EDID/HDCP 分区 → FULL/Reduce/Reduce_CFG"]
```

### 2.2 决定"编哪些目录"的三个变量

make 里所有路径都由这三个变量拼出，**Makefile 本身不需要改**：

| 变量 | 来源 | 决定什么 |
|---|---|---|
| `$(CONFIG_PROJECT)` | `out/.config`（由 `build.sh:92-93` 的 `basename pwd` 传入） | 选哪个机型工程目录 |
| `$(GR_*_NAME)` | `build.sh:26-35` 从产品配置头 grep 后 `export` | 选 OSD / DataBase / 板卡 / 屏参 / 按键变体 |
| `$(CONFIG_CHIP)` | `out/.config` | 选 `ht6315a` / `ht6315c` 芯片分支 |

> 关键认知：`GR_CUSTOM_PROJECT` 是**文件名令牌**不是数值 ID——`build.sh` 只取右侧单词，
> `common.inc:70` 直接拼成 `ProjectConfig/<该名字>.h` 被 `-include`。
> 而 `GR_*_NAME` 写在 `out/.config` 里是无效的：它们是 shell 环境变量，由 make 继承。

### 2.3 三条互相独立的源文件路径

1. **PRE_CHECK**：只编 `build/BuildCheck/AllConfigCheck.c`（`build/Makefile:72-78`），`.o` **不链接**进固件，作用是触发 `AllConfigCheck.h` 的 `#error` 校验
2. **11 个静态库**：各 `Makefile.mk` 的 `wildcard` 收集 `.c`/`.S` → `ar` 打包到 `out/<chip>/img/lib*.a`
3. **直接链接**：`build/Makefile.mk:50` 的 `wildcard $(SDK_MIDDLEWARE_DIR)/*.c` 即 `sdk/MiddleWare/main.c`，不入库

### 2.4 当前生效配置（HT6315A 精简工作区）

2026-11-07 起，工作区 `GRHX_6315AC_Series` 已精简为仅 A 工程，完整备份在 `/code/6315/GRHX_6315A_Study`。

```
CONFIG_CHIP=ht6315a   CONFIG_VENDOR=GRHX   CONFIG_PROJECT=HT6315A_DEMO_1A1H
CONFIG_MODEL=ht6315a_demo_1A1H68   CONFIG_DP=no   CONFIG_VGA=yes
CONFIG_PRINT=yes  CONFIG_FAKEDC=yes  CONFIG_SECOND_UART=no
```

产品头 `ProjectConfig_Demo.h` 选定：`GR_BOARD_NAME=GR_HG301Test`、
`GR_PANEL_NAME=LVDS_SN270CS05_1_FHD144_DEMO_A`、`GR_OSD_NAME=OSD_MyDemo`、
`GR_DataBase_NAME=OSD_MyDemo`、`GR_KEY_NAME=KEY_Demo`。
`DEFAULT_DEBUG_VERSION=debug`（`build.sh:4`）——与 C 工程的 release 不同，因此 **LetterShell 会参与编译**。

> 精简结果：345M / 3383 文件 → **24M / 922 文件**；仅 1 个机型、1 套 OSD/DataBase、1 块板卡、1 份屏参。
> 其余专题（`panel-porting.md` / `edid-porting.md` 等）里出现的 C 工程路径来自精简前的代码，
> 在备份目录中仍可查到，当前工作区已不存在。

## 3. 参与编译的源码目录清单（HT6315A，84 个目录 / 235 个源文件）

数字 = 该目录被 `wildcard` 收集的 `.c`/`.S` 数。路径相对项目根。

### 3.1 Boot / Loader / Vos → libloader.a / libboot.a / libvos.a

| 目录 | 数 | 目录 | 数 |
|---|---|---|---|
| `sdk/Loader/Chip/ht6315a` | 2 | `sdk/Boot/Chip/ht6315a` | 7 |
| `sdk/Boot/Common` | 2 | `sdk/Vos/src` | 4 |
| `sdk/Vos/ht6315a/src` | 4 | `sdk/Vos/nonos/src` | 6 |

### 3.2 sdk/Common → libcommon.a

| 目录 | 数 | 备注 |
|---|---|---|
| `sdk/Common/Event` | 2 | |
| `sdk/Common/MemParser` | 1 | |
| `sdk/Common/Timer/src` | 1 | |
| `sdk/Common/Util/HvQueue/src` | 1 | |
| `sdk/Common/Util/Utilities/ht6315a/src` | 2 | 由 `Utilities/Makefile.mk` 按 `$(CONFIG_CHIP)` 选中 |
| `sdk/Common/Debug/LetterShell/src` | 15 | **仅 debug**：`sdk/Common/Debug/Makefile.mk` 的 `ifeq ($(COMPILE_MODE),debug)` |
| `sdk/Common/Debug/LetterShell/src/performance/coremark` | 8 | `SDK_WITH_PERF_TEST=no`，实际不编 |

### 3.3 sdk/MiddleWare → libmiddleware.a（+ 直接链接的 main.o）

| 目录 | 数 | 目录 | 数 |
|---|---|---|---|
| `sdk/MiddleWare`（仅 `main.c`，直接链接） | 1 | `sdk/MiddleWare/ChannelManager/src` | 2 |
| `sdk/MiddleWare/ChannelManager/Audio/src` | 2 | `sdk/MiddleWare/ChannelManager/Video/src` | 4 |
| `sdk/MiddleWare/InputPortManager/src` | 1 | `sdk/MiddleWare/InputPortManager/Ddcci/src` | 2 |
| `sdk/MiddleWare/InputPortManager/DisplayPort/src` | 1 | `sdk/MiddleWare/InputPortManager/HDCP/src` | 3 |
| `sdk/MiddleWare/InputPortManager/HDMI/src` | 1 | `sdk/MiddleWare/InputPortManager/VGA/src` | 1 |
| `sdk/MiddleWare/OSD/src` | 8 | `sdk/MiddleWare/PanelManager/src` | 1 |
| `sdk/MiddleWare/PowerManager/src` | 1 | `sdk/MiddleWare/RunTime/SystemTask/src` | 1 |
| `sdk/MiddleWare/RunTime/UrgentTask/src` | 1 | `sdk/MiddleWare/RunTime/OsdTask/src` | 1 |

### 3.4 sdk/Driver → libdriver.a（芯片层均 ht6315a）

| 目录 | 数 | 目录 | 数 |
|---|---|---|---|
| `sdk/Driver/Audio/drv/src` | 1 | `sdk/Driver/Audio/cal/ht6315a/src` | 1 |
| `sdk/Driver/DPU/drv/src` | 2 | `sdk/Driver/DPU/cal/ht6315a/src` | 1 |
| `sdk/Driver/Ddcci/src` | 1 | `sdk/Driver/DisplayCtrl/drv/src` | 4 |
| `sdk/Driver/DisplayCtrl/cal/ht6315a/src` | 3 | `sdk/Driver/DisplayPort/drv/src` | 1 |
| `sdk/Driver/HDCP/drv/ht6315a/src` | 2 | `sdk/Driver/HDMI/drv/ht6315a/src` | 1 |
| `sdk/Driver/OSD/drv/src` | 17 | `sdk/Driver/OSD/cal/src` | 16 |
| `sdk/Driver/PHY/drv/ht6315a/src` | 1 | `sdk/Driver/PHY/cal/ht6315a/src` | 1 |
| `sdk/Driver/PMU/drv/src` | 1 | `sdk/Driver/PMU/cal/ht6315a/src` | 1 |
| `sdk/Driver/Peripheral/drv/src` | 11 | `sdk/Driver/Peripheral/cal/ht6315a/src` | 8 |
| `sdk/Driver/RxBridge/drv/ht6315a/src` | 1 | `sdk/Driver/RxBridge/cal/ht6315a/src` | 1 |
| `sdk/Driver/TX/EdpTx/drv/src` | 2 | `sdk/Driver/TX/KTX/drv/ht6315a/src` | 1 |
| `sdk/Driver/TX/KTX/cal/ht6315a/src` | 1 | `sdk/Driver/TX/LvdsTx/drv/src` | 1 |
| `sdk/Driver/TX/LvdsTx/cal/ht6315a/src` | 1 | `sdk/Driver/TX/MPRT/drv/src` | 1 |
| `sdk/Driver/TX/MPRT/cal/ht6315a/src` | 1 | `sdk/Driver/TX/MlvdsTx/drv/src` | 1 |
| `sdk/Driver/TX/MlvdsTx/cal/ht6315a/src` | 1 | `sdk/Driver/VGA/drv/src` | 1 |
| `sdk/Driver/VGA/cal/ht6315a/src` | 1 | | |

> 与 C 工程（HT6315C / release）的差异：A 工程多 `VGA/cal/ht6315a/src`、
> `MlvdsTx/cal/ht6315a/src`、`KTX/drv/ht6315a/src`，少 `EdpTx/cal/ht6315a/src`；
> C 工程另编 LetterShell 之外的 `VGA/cal` 等分支。`CONFIG_DP/no`、`CONFIG_VGA/yes`
> 只影响 `-D` 编译宏，**不影响 Makefile 的 include 链**。

### 3.5 user/Comm（共享代码）

| 目录 | 数 | 归属 |
|---|---|---|
| `user/Comm/DDCCI/src` | 2 | libddcci.a |
| `user/Comm/EDID/src` | 4 | libedidcommon.a |
| `user/Comm/Factory/src` | 1 | libmiddleware.a |
| `user/Comm/Panel/src` | 1 | libmiddleware.a |
| `user/Comm/Board/GR_HG301Test/Pinshare/src` | 1 | libdriver.a（引脚复用，见 `board-porting.md`） |

### 3.6 user/GRHX/HT6315A_DEMO_1A1H（机型专属）

| 目录 | 数 | 归属 |
|---|---|---|
| `.../OSD/OSD_MyDemo/Behaviour/src` | 4 | libosd.a |
| `.../OSD/OSD_MyDemo/Common/src` | 1 | libosd.a |
| `.../OSD/OSD_MyDemo/Resource/Composer/src` | 4 | libosd.a |
| `.../OSD/OSD_MyDemo/Resource/Matrix` | 3 | libosd.a |
| `.../OSD/OSD_MyDemo/Resource/Matrix/{bmp,corner,palette}/src` | 各 1 | libosd.a |
| `.../OSD/OSD_MyDemo/Resource/Matrix/font/src` | 23 | libosd.a |
| `.../DataBase/OSD_MyDemo/src` | 1 | libdatabase.a |
| `.../EDID` | 2 | libedid.a |
| `.../DDCCI/src` | 2 | libddcci.a |
| `.../PQ/src`、`.../RX/src` | 各 2 | libmiddleware.a |
| `.../Channel/src` | 1 | libmiddleware.a |
| `.../BackLight/src` | 1 | libdriver.a |
| `.../Keypad/Src`、`.../Led/Src` | 各 1 | libmiddleware.a |
| `.../System/EventHub/src` | 1 | libmiddleware.a |

### 3.7 编译但不链接 / 声明 wildcard 但不编译

| 目录 | 说明 |
|---|---|
| `build/BuildCheck` | PRE_CHECK 的 `AllConfigCheck.c`，`.o` 不进 `LIB_STATIC` |
| `sdk/MiddleWare/InputPortManager/HDCP/aesdeckey` | 只被 `prebuilds/Makefile.mk` 引用，而 `prebuilds.inc` 被注释；由 `prebuilds/ht6315a/libAesKey.a` 提供 |
| `sdk/Driver/{HDCP/cal,HDCP/Engine,HDMI/cal,PLL/cal}` 源码 | 同上，用预编译 `.a` |
| `sdk/Common/Debug/LetterShell/src/performance/coremark` | `SDK_WITH_PERF_TEST=no`（`build/Makefile:55`） |
| `sdk/test/test_vdm`、各 OSD 变体 `ResourceTest/` | `SDK_WITH_DPU_VDM_TEST=no`、`SDK_WITH_OSD_TEST=no` |

## 4. 头文件注入 / 引用 / 资源目录（不产生 `.o`）

`build/compile/common.inc:66-83` 把 **10 个配置头全局 `-include`** 进每条编译命令：

| # | 注入头文件 | 行 |
|---|---|---|
| 1 | `user/Comm/Board/BoardList.h` | `:66` |
| 2 | `user/Comm/Panel/PanelList/PanelList.h` | `:68` |
| 3 | `user/GRHX/<机型>/ProjectConfig/<GR_CUSTOM_PROJECT>.h`（产品头） | `:70` |
| 4 | `user/Comm/Board/$(GR_BOARD_NAME)/GR_BoardConfig.h` | `:74` |
| 5 | `user/GRHX/<机型>/ProjectConfig.h` | `:75` |
| 6 | `user/Comm/Panel/inc/PanelConfig.h` | `:76` |
| 7 | `user/Comm/Panel/PanelList/$(GR_PANEL_NAME)/GR_PanelConfig.h` | `:78` |
| 8 | `user/GRHX/<机型>/OSD/$(GR_OSD_NAME)/OsdConfig.h` | `:80` |
| 9 | `user/Comm/ProjectConfig_Default.h`（按芯片再含 `_HT6315A.h` / `_HT6315C.h`） | `:81` |
| 10 | `user/GRHX/<机型>/Keypad/Userkey/$(GR_KEY_NAME).h` | `:83` |

**顺序要点**：产品头（3）**早于** `ProjectConfig.h`（5）和缺省头（9），
所以 `HV_CONFIG_ON/OFF` 与 5 个 `GR_*_NAME` 必须在产品头里定义，缺省头的 `#ifndef` 才能正确兜底。

| 分类 | 目录 |
|---|---|
| `-I` 头文件 | `sdk/Driver/Arch/<chip>/{,regs,regs_offset}`、`sdk/Vos/inc`、各 `sdk/**/inc`、`user/**/inc` |
| PRE_CHECK 显式 `-I` | `user/Comm`、`user/GRHX/<机型>`、`user/Comm/Panel/inc`、`build/BuildCheck`（`build/Makefile:77`） |
| 预编译库 | `prebuilds/<chip>/` — 10 个 `.a`，PRE_CHECK 时 `cp` 进 img 后链接（`build/Makefile:78`） |
| 链接脚本 | `build/scripts/ldscript/<chip>/` — `<chip>_silicon_rom.ld` / `...-db.ld` |
| 产物 | `out/<chip>/obj/`（`.o`）、`out/<chip>/img/`（`.a/.elf/.map/.bin`）、`out/` |
| 打包资源 | `user/GRHX/<机型>/Prebuilds/` — `CALSUM`、`LOGO/`、`PQ/<model>/`，make 之后合并，不进编译链 |

## 5. 常见坑点 / 注意

### 5.1 精简代码前必须做「悬空 include 预检」

删除"看起来不相关"的变体目录前，先扫描全仓 Makefile 的 `include` 目标并模拟删除：

1. 收集所有 `Makefile` / `Makefile.mk` / `*.inc` 里的 `include <path>`，按 `$(CONFIG_*)`、`$(GR_*_NAME)` 展开
2. 生成待删路径集合，逐个检查每个 include 目标是否落在待删集合内
3. 同时检查 10 个 `-include` 头与所有 `wildcard` 源目录
4. **误删数为 0 才执行删除**

2026-11-07 精简时预检结果：127 个 include 目标（125 有效）、157 个有效 include、10 个 `-include` 头、84 个源目录，误删 0。

### 5.2 硬编码异芯片 include（删除时的头号陷阱）

```1:1:sdk/Driver/TX/EdpTx/cal/Makefile.mk
include $(SDK_DRIVER_DIR)/TX/EdpTx/cal/ht6315c/Makefile.mk
```
```1:1:sdk/Driver/TX/MlvdsTx/cal/Makefile.mk
include $(SDK_DRIVER_DIR)/TX/MlvdsTx/cal/ht6315a/Makefile.mk
```

这两处**不随 `CONFIG_CHIP` 变化**。所以切到 `ht6315a` 工程后，
`EdpTx/cal/ht6315c/Makefile.mk` **仍必须保留**，否则 `make` 直接报 include 找不到；
该文件内部 wildcard 用 `$(CONFIG_CHIP)`，在 A 工程展开为空、不产生 `.o`，纯粹是 include 链需要。
同理 `MlvdsTx/cal/ht6315a/Makefile.mk` 在 C 工程也必须保留。

### 5.3 其它易踩的坑

- **不能删的"看起来不相关"项**：`BoardList.h` / `PanelList.h`（全局 ID 宏表）、
  `ProjectConfig_Default*.h`（缺省宏）、`out/.config`（`build/Makefile:62-64` 缺失直接 `$(error)`）、
  `.git/` / `.codebuddy/` / `.continue/`
- **`prebuilds.inc` 被注释**（`build/Makefile:69`）：`prebuilds/Makefile.mk`、`tools/` 完全不参与；
  预编译 `.a` 由 PRE_CHECK 的 `cp prebuilds/$(CONFIG_CHIP)/*.a` 提供，别去删 `prebuilds/<chip>/`
- **同名 `.c` 跨变体重复**：各 OSD 变体、A/C 芯片分支常有同名源文件，
  用 `.o` 反查目录会产生多候选，必须限定在 `wildcard` 展开的候选集合内取交集
- **debug / release 影响编译目录**：LetterShell 只在 debug 下 include（`sdk/Common/Debug/Makefile.mk`）；
  A 工程默认 debug、C 工程默认 release，同一份代码两工程的目录清单不同
- **`CONFIG_MODEL` 只是记录**：写进 `out/.config` 但无 Makefile 读取，真正驱动 `Prebuilds/PQ/<model>/` 和 bin 名的是 shell 变量 `SELECTED_MODEL`
- **必须在机型目录里跑 `build.sh`**：`CONFIG_PROJECT` 来自 `basename pwd`，`ROOTPATH` 假定三级目录深度
- **`AllConfigCheck.o` 编但不链**：它的作用是触发 `AllConfigCheck.h` 的 `#error`，不要误以为它进了固件

## 6. 核对方法（可复现）

```bash
R=<项目根>; A=$R/user/GRHX/HT6315A_DEMO_1A1H

# 1) 用构建脚本原生方式生成 A 工程 .config
cd $R/build && bash project_config.sh GRHX HT6315A_DEMO_1A1H ht6315a_demo_1A1H68 ht6315a rom silicon

# 2) make dry-run：打印所有 wildcard 源文件收集变量（不执行编译）
cd $R/build && GR_OSD_NAME=OSD_MyDemo GR_DataBase_NAME=OSD_MyDemo \
  GR_BOARD_NAME=GR_HG301Test GR_PANEL_NAME=LVDS_SN270CS05_1_FHD144_DEMO_A \
  GR_KEY_NAME=KEY_Demo GR_CUSTOM_PROJECT_FILE=ProjectConfig_Demo \
  make -pn release | grep -E '^OBJ_[A-Z0-9_]*_C[[:space:]]*='

# 3) 真实编译验证配置链（零副作用，输出到 /tmp）
sparc-gaisler-elf-gcc -mcpu=leon3 -Wall -Werror -msoft-float \
  -DHV_CONFIG_CHIP_HT6315A ... \
  -include $R/user/Comm/Board/BoardList.h ... \
  -c $R/build/BuildCheck/AllConfigCheck.c -o /tmp/check.o

# 4) 完整编译（会 make clean 并重新生成 out/ 产物）
cd $A && bash build.sh
```

`make -pn` 需带齐 `build.sh` 会 export 的 `GR_*` 变量，否则会出现
`user/Comm/Board//Pinshare/Makefile.mk` 这类因变量为空导致的假报错。

验证基准：A 精简工作区按完整 10 个 `-include` 注入编译 `AllConfigCheck.c` → `EXIT_CODE=0`，
`make -pn` 展开 **84 个 wildcard 源目录 / 235 个源文件**；
C 工程（历史）为 82 个目录 / 223 个 `.o`。

## 7. 关联专题

- 相关：`[[architecture]]`（分层与启动链路）、`[[board-porting]]`（板卡目录与 Pinshare）、
  `[[panel-porting]]`（屏参 `-include` 选中）、`[[edid-porting]]`（EDID 表所在的配置头）、
  `[[cheatsheet]]`（关键文件速查）
