# 专题：EDID 修改（HDMI / DP / VGA）

> 定位：修改显示器向主机声明的能力信息（厂商、型号、分辨率/刷新率、色域、HDR、FreeSync、音频等）。
> 与 `board-porting.md` / `panel-porting.md` 是姊妹篇：主板管脚、屏参管点屏，**EDID 管"主机识别到什么"**。

## 0. 结论：属于哪一层？
- **user 层（主战场）**：EDID **字节表本体**在 `user/GRHX/<机型>/ProjectConfig/ProjectConfig_<工程>.h`
  的 `TBL_EDID_HDMI_DEFAULT` / `TBL_EDID_HDMI_VRR` / `TBL_EDID_DP_DEFAULT` 等宏里；
  `user/GRHX/<机型>/EDID/*.c` 把宏组装成默认 EDID 数据库；
  `DataBase/<OSD>/inc/hv_comm_DataBase.h` 定义 `HdmiEdidDBRegion` 与 Flash 地址；
  `System/hv_comm_FlashConfig.h` 定义 EDID Flash 分区大小；
  `user/Comm/ProjectConfig_Default_HT6315x.h` 提供 `HV_PROJECT_CONFIG_DEFAULT_EDID` 等开关缺省值。
- **MiddleWare 层**：`user/Comm/EDID/`（通用逻辑：Init/Update/Write/校验和/工厂信息）、
  `sdk/MiddleWare/InputPortManager/{HDMI,DisplayPort,VGA}/`（开机初始化、写 RX RAM、切换 EDID、HPD toggle）。
- **Driver 层**：`sdk/Driver/HDMI/drv/ht6315c/src/hv_drv_HdmiRx.c`（e-seg / DDC 寄存器）、
  `hv_cal_HdmiRx_UpdateEdidData()`、`hv_drv_Flash.*`（XIP 读 / 擦写）；DDC 端口由板级
  `HV_BOARD_CONFIG_HDMI_DDC_PORT_BYINDEX` 决定。
- **build 层**：`build.sh` 负责 EDID 分区占位（`edid.bin` → `edid_padded.bin`）、superblk 合并、
  `EDID_VERSION` 与量产提醒。
- **Boot 层**：不参与。

> **最重要的认知**：EDID 字节表和屏参一样，是**编译期 `-include` 注入的宏**，不是运行时读配置文件。
> 它定义在 `ProjectConfig/*.h` 里，由 `common.inc` 全局注入，`EDID/*.c` 用这些宏填 `const` 数组，
> 最终编进固件。改 EDID 表必须**重新编译**。

## 1. 两条数据路径（决定"改了会不会生效"）

| 模式 | 开关 | 数据来源 | 外部能否烧录 |
|---|---|---|---|
| **默认 EDID**（缺省，开发阶段） | `HV_PROJECT_CONFIG_DEFAULT_EDID == HV_CONFIG_ON` | 代码里的 `s_stDefaultHdmiEdidDBRegion` | **不能**：`Hv_Mw_HdmiRx_WriteHdmiEdid()` 直接 `// do nothing; return HV_SUCCESS` |
| **自定义 EDID**（量产） | `== HV_CONFIG_OFF` | Flash `HDMIEDID_DATA_START_ADDRESS`（XIP 读）或外部 EEPROM（`HV_PROJECT_CONFIG_EDID_EXTER_EEPROM == ON`） | 可以：DDC/CI 工具 / shell / 工厂流程写入 |

缺省值见 `user/Comm/ProjectConfig_Default_HT6315C.h:84-88`（`DEFAULT_EDID = ON`、`EXTER_EEPROM = OFF`）。

`Hv_Mw_HdmiRx_GetDatabaseEdid()`（`user/Comm/EDID/src/hv_mw_HdmiEdidCommon.c:560`）是分岔点：
- `ON`：`memcpy` 默认表 → `Hv_EdidCommon_SetFactoryEdidInfo()` 运行时把周/年/产品 SN 写进 EDID
  → HDMI1 端口额外 `Hv_EdidCommon_UpdateCecAddr(..., 0x10)` → 打印 `"%u EDID use in code"` 并返回。
- `OFF`：`Hv_Drv_Flash_ReadXIP(HDMIEDID_DATA_START_ADDRESS, ...)`；若 `uiMagicNumber` 不等于
  `DATABASE_VALID_MAGIC_NUMBER`，按 `HV_PROJECT_CONFIG_EDID_INVALID_REPLACE` 决定是否回退默认表，
  打印 `"EDID not found in flash..."` / `"EDID found in flash..."`。

> **头号坑**：一旦量产关掉 `DEFAULT_EDID` 且 Flash 里烧过有效 EDID，
> **改源码里的 `TBL_EDID_*` 就完全不起作用**（运行时读 Flash）。日志里的 `"EDID use in code"`
> vs `"EDID found in flash..."` 是判断走哪条路径的最快方法。

## 2. 默认 EDID 数据库结构

```29:50:user/GRHX/HT6315C_DEMO_1D1H/EDID/hv_edid_HdmiEdid.c
const HdmiEdidDBRegion s_stDefaultHdmiEdidDBRegion =
{
    .usCheckCrc = 0x0,
    .uiMagicNumber = DATABASE_VALID_MAGIC_NUMBER,
    .astHdmiEdid =
    {
        { .eEdidType = EDID_TYPE_DEFAULT,  .uiEdidLen = GR_HDMI_EDID_SIZE, .acEdid = { TBL_EDID_HDMI_DEFAULT } },
        { .eEdidType = EDID_TYPE_TMDS_VRR, .uiEdidLen = GR_HDMI_EDID_SIZE, .acEdid = { TBL_EDID_HDMI_VRR } },
        // 可选: EDID_TYPE_OVERCLOCK / OVERCLOCK_VRR / MANUAL_HDMI(n)
    },
    .ucNumber = 2,          // 超频开启时为 4
    .bModifyFlag = HV_FALSE
};
```
- 字节表宏示例（当前工程 `ProjectConfig_WLK_DEMO_HK301_..._SG2701B08_1_V7_1_FHD165.h:79-128`）：
  `#define TBL_EDID_HDMI_DEFAULT\` 后接 384 字节、每行 16 个 `0xXX,`、行尾 `\` 续行。
  头 8 字节固定 `00 FF FF FF FF FF FF 00`（EDID header）。
- **多套表按 `EDIDType` 切换**：`Hv_Mw_HdmiRx_GetEdidType()` 按 `UserData.ucFreeSync` / `bOverClocking`
  选 `DEFAULT` / `TMDS_VRR` / `OVERCLOCK` / `OVERCLOCK_VRR`；
  `Hv_Mw_HdmiRx_CheckEdidTypeValid()` 校验类型合法，`Hv_Mw_HdmiRx_UpdateEdid()` 负责切换。
- DP 表在 `EDID/hv_mw_DpEdid.c`（`TBL_EDID_DP_DEFAULT`）；VGA 表在 `DataBase/<OSD>/inc/hv_comm_VgaDef.h`。

## 3. 详细修改步骤

### 步骤 1 — 确认当前生效工程
`user/GRHX/<机型>/ProjectConfig.h` 的 `GR_CUSTOM_PROJECT` → 打开 `ProjectConfig/<该值>.h`。
EDID 表、尺寸宏、开关都在这份文件里（不是 `user/Comm/EDID/`）。

### 步骤 2 — 准备新 EDID 二进制
用 EDID 编辑工具（如 EEdit / Phoenix EDID Designer / 厂商工具）导出 `.bin`，或按需求手工改字节。
长度必须是 **128 的整数倍**（1 块=128；256=2 块；384=3 块；512=4 块）。

### 步骤 3 — 校验并修正 CheckSum（最容易错）
每个 128 字节块的**最后一字节** = `0x00 - 前 127 字节累加和`（取低 8 位）。
```88:100:user/Comm/EDID/src/hv_mw_EdidCommon.c
static UCHAR8 Hv_EdidCommon_CalCheckSum(UCHAR8 *pucData, UCHAR8 ucLength)
{
    ...
    return ((UCHAR8)0x00 - ucValueSum);
}
```
- 多个扩展块（block1/2/3）**每块都要单独算**，`Hv_Mw_HDMI_EdidCheckValid()` 会逐块校验。
- `Hv_EdidCommon_InsertEdidBlockData()` / `InsertEdidDescSn()` 会自动重算 **block0** 的 checksum。
- checksum 错 → 主机读到无效 EDID、识别成通用显示器或直接不输出。

### 步骤 4 — 替换字节表宏并同步尺寸
- 把 `.bin` 转成 `0xXX, 0xXX, ...\` 格式，替换 `TBL_EDID_HDMI_DEFAULT`（及 `TBL_EDID_HDMI_VRR` 等）。
- 同步 `GR_HDMI_EDID_SIZE`（HDMI）、`GR_DP_EDID_SIZE`（DP）为**实际字节数**。
- 当前工程：`GR_HDMI_EDID_SIZE 384`、`GR_DP_EDID_SIZE 384`。

### 步骤 5 — 核对长度 / 数量上限（越界会静默截断）
| 上限 | 值 | 来源 |
|---|---|---|
| `HV_HDMI_MAX_EDID_LENTH` | 256（`ALLOW_EDID_E_SEG=OFF`）/ 512（ON） | `sdk/Common/hv_comm_Define.h:65-69` |
| `HV_DP_MAX_EDID_LENTH` | 384 | `hv_comm_Define.h:72` |
| `VGA_EDID_MAX_LENGTH` | 128 | `DataBase/<OSD>/inc/hv_comm_VgaDef.h` |
| `HDMI_EDID_MAX_NUMBER` | 2（超频开启 4） | `DataBase/<OSD>/inc/hv_comm_DataBase.h` |
| `HV_EDID_BLOCK_DATA_SIZE` | 128 | `hv_comm_Define.h:58` |

- `acEdid[HV_HDMI_MAX_EDID_LENTH]` 是定长数组，**`GR_HDMI_EDID_SIZE` 不得超过它**。
- 6315C 缺省 `ALLOW_EDID_E_SEG = ON`（512），6315A 为 `OFF`（256）——
  **384 字节的 EDID 只能在 6315C 用**，拿到 6315A 会越界。
- `Hv_Mw_HdmiRx_SetEdidToRamReg()` 会 `usEdidLen <= MAX ? usEdidLen : MAX` **静默 clamp**，
  不报错但 EDID 被截断，务必提前核对。

### 步骤 6 — 多套 EDID 同步
若项目支持 FreeSync / 超频 / OSD 手动切换，需**同时**改 `TBL_EDID_HDMI_VRR`、
`TBL_EDID_HDMI_OVERCLOCK(_VRR)`、`TBL_EDID_SWITCH_HDMI_EDIDn`，并按开关调整
`.ucNumber`（`GR_PROJECTCONFIG_CONFIG_OVERCLOCK_HDMI`、`HV_PROJECT_CONFIG_EDID_MANUAL_SWITCH`）。
只改 DEFAULT 会导致用户开 FreeSync 后仍拿到旧 EDID。

### 步骤 7 — 配套改动
- DP 表 `TBL_EDID_DP_DEFAULT`、VGA 表（若有该端口）。
- `HV_PROJECT_CONFIG_FW_EDID_VERSION`（缺省 = `GR_FACTORY_FW_PCBA_VERSION`）：只影响 bin 命名/版本标识。
- `HV_PROJECT_CONFIG_FACTORY_PANEL_NAME`、OSD 里显示的型号字符串。
- 换屏后 EDID 的**分辨率/刷新率/显示器名**必须与新屏参一致（参见 `panel-porting.md` 步骤 7）。

### 步骤 8 — 编译并验证
- 跑 `build.sh`，`strings out/Monitor_SOC.bin` 可查 EDID 头字节（但表是 `const` 数组，用日志更可靠）。
- 开机串口日志：
  - `"%u EDID use in code"` → 走默认表，改源码生效；
  - `"EDID found in flash..."` → 走 Flash，改源码无效；
  - `"Hdmi edid checksum error"` / `"Hdmi edid head error"` → checksum/头字节错误。
- 主机侧：Windows 设备管理器 / Linux `edid-decode` / `xrandr --prop` 读回 EDID 核对。

### 步骤 9 — 让主机重新读取（HPD toggle）
改完 EDID 后主机通常仍缓存旧信息，需要热插拔或代码触发 HPD：
```293:296:user/Comm/EDID/src/hv_mw_HdmiEdidCommon.c
            if (bToggleHpd)
            {
                Hv_Mw_HdmiRx_ToggleHdmiHPD(enPortIndex, HDMI_HOT_PLUG_LONG_TIMER_LENGTH);
            }
```
对外接口：`Hv_Mw_HdmiRx_UpdateEdidWithToggleHpd()`（切换+HPD）、
`Hv_Mw_HdmiRx_UpdateEdidWithoutToggleHpd()`（仅切换）。

### 步骤 10 — 量产切换到自定义 EDID
把 `HV_PROJECT_CONFIG_DEFAULT_EDID` 设为 `HV_CONFIG_OFF` 后：
- **DDC/CI 烧录**：`user/GRHX/<机型>/DDCCI/src/hv_app_DdcciTPV.c:2957-2975`，
  按 `MNT_EDID_HDCP_DEVID_HDMI1_V14` 等设备 ID 分包收齐（≥256 字节），
  调 `Hv_Mw_HdmiRx_WriteHdmiEdid()` + `Hv_Mw_HdmiRx_InitEdid()` **立即生效不重启**；
  写入 Flash 用 `Hv_Drv_Flash_OnlyErase` + `Hv_Drv_Flash_OnlyWrite`（`HDMIEDID_DATA_START_ADDRESS`）。
- **shell 调试**：`sdk/Common/Debug/LetterShell/src/hv_comm_shell_hdmi_debug.c:150`
  `Hv_Mw_HdmiRx_SetHdmiToEeprom()` 写外部 EEPROM。
- 外部 EEPROM 模式：`HV_PROJECT_CONFIG_EDID_EXTER_EEPROM = ON`，
  由 `FactoryData.ucHdmiEepBurn == 0xAA` 判断是否已烧录过，避免重复写。

## 4. 生效链路（mermaid）

```mermaid
flowchart TD
    A["ProjectConfig/<工程>.h\nTBL_EDID_* 宏 + GR_*_EDID_SIZE"] -->|"common.inc -include"| B["EDID/*.c\ns_stDefaultHdmiEdidDBRegion"]
    B --> C["Hv_Mw_HdmiRx_InitEdid(port, type)\n(开机 hv_mw_Hdmi.c:2112)"]
    C --> D{"HV_PROJECT_CONFIG_DEFAULT_EDID"}
    D -->|ON| E["GetDatabaseEdid: memcpy 默认表\n+ SetFactoryEdidInfo(周/年/SN)\n+ UpdateCecAddr(HDMI1)"]
    D -->|OFF| F["Hv_Drv_Flash_ReadXIP\nHDMIEDID_DATA_START_ADDRESS"]
    E --> G["Hv_Mw_HdmiRx_SetEdidToRamReg"]
    F --> G
    G --> H["Hv_Cal_HdmiRx_UpdateEdidData\n(写 RX DDC EDID RAM, e-seg 开关)"]
    H --> I["主机经 DDC 读取 EDID"]
    J["切换/更新"] --> K["UpdateEdid(bToggleHpd)\n→ ToggleHdmiHPD 让主机重读"]
    K --> G
    L["量产 DDC/CI 烧录"] --> M["WriteHdmiEdid\n→ Flash / EEPROM"]
    M --> F
```

## 5. 打包与 Flash 分区
- `user/GRHX/<机型>/System/hv_comm_FlashConfig.h:130-132`：
  `HV_FLASH_CONFIG_CFIG_DPEDID_SIZE (4*1024)`、`HDMIEDID_SIZE (4*1024)`、`HDCP_SIZE (4*1024)`。
  地址宏 `HDMIEDID_DATA_START_ADDRESS` 在 `DataBase/<OSD>/inc/hv_comm_DataBase.h`。
- `build.sh`：`EDID_SIZE = DPEDID_SIZE + HDMIEDID_SIZE`；
  `touch edid.bin` → `pad_file edid.bin $EDID_SIZE edid_padded.bin`（填 0xFF 占位）
  → `add_*_super_blk EDID edid_padded.bin $EDID_SIZE` 合并进 FULL / Reduce / Reduce_CFG 三类升级包。
  **注意：默认表编在代码里，这个 `edid.bin` 只是给"运行时烧录的自定义 EDID"预留的空白分区**。
- `EDID_VERSION` 从 `HV_PROJECT_CONFIG_FW_EDID_VERSION` 取，仅用于 bin 文件命名。

### 关于 `Please remember to disable the default EDID!!!`
`build.sh:1601` 用 `grep "HV_PROJECT_CONFIG_DEFAULT_EDID.*HV_CONFIG_ON" "$PROJECT_CONFIG_FILE"`
判断，非空则打印这条红字（`PRINT_EDID_WARNING_INFO=true`）。
它是**量产提醒**：提醒量产前把默认 EDID 关掉、改用烧录的自定义 EDID，
**不是编译错误，也不是"缺文件导致变量为空"**。
`$PROJECT_CONFIG_FILE` 默认指向 `user/Comm/ProjectConfig_Default_HT6315C.h`，
若其中有 `#include "ProjectConfig/..."` 且文件存在才重定向到工程配置头（`build.sh:137-147`）——
所以即使工程配置里没写 `DEFAULT_EDID`，缺省头里的 `ON` 也会触发该提醒。
同理还有 `Please remember to disable the default HDCP KEY!!!`（HDCP 默认 key）。

## 6. 常见坑点
1. 改了源码表没生效 → `DEFAULT_EDID=OFF` 且 Flash 已有有效 EDID；看日志 `"EDID use in code"` 还是 `"found in flash"`。
2. CheckSum 错（尤其只算了 block0，漏了扩展块）→ 主机不识别；每 128 字节块都要算。
3. 长度超过 `HV_HDMI_MAX_EDID_LENTH` → `SetEdidToRamReg` 静默 clamp 截断；
   384 字节 EDID 需 `ALLOW_EDID_E_SEG=ON`（6315C 支持，6315A 不支持）。
4. 多套表不同步（DEFAULT 改了、VRR/超频没改）→ 用户开 FreeSync/超频后拿到旧能力集。
5. 只改 HDMI 忘了 DP / VGA。
6. 手工填的周/年/序列号会被 `Hv_EdidCommon_SetFactoryEdidInfo()` 运行时用 FactoryData 覆盖并重算 checksum。
7. 改完没 HPD toggle → 主机仍缓存旧 EDID，以为没生效。
8. 换屏后 EDID 的分辨率/刷新率/显示器名与新屏参不一致。
9. `EDID_VERSION` 为空只是打包命名变量取不到（缺省值是宏名不是字符串），不影响功能。

## 7. 关键文件速查
| 作用 | 路径 |
|---|---|
| **EDID 字节表（改这里最多）** | `user/GRHX/<机型>/ProjectConfig/ProjectConfig_<工程>.h` 的 `TBL_EDID_*` |
| 尺寸 / e-seg / 开关宏 | 同上 `GR_HDMI_EDID_SIZE`、`GR_DP_EDID_SIZE`、`HV_PROJECT_CONFIG_ALLOW_EDID_E_SEG` |
| 缺省开关值 | `user/Comm/ProjectConfig_Default_HT6315x.h`（`DEFAULT_EDID`、`EXTER_EEPROM`、`EDID_MANUAL_SWITCH`） |
| 默认表容器（HDMI/DP） | `user/GRHX/<机型>/EDID/hv_edid_HdmiEdid.c`、`hv_mw_DpEdid.c` |
| 结构体 / 数量 / Flash 地址 | `user/GRHX/<机型>/DataBase/<OSD>/inc/hv_comm_DataBase.h` |
| 通用逻辑（Init/Update/Write/校验和） | `user/Comm/EDID/src/{hv_mw_HdmiEdidCommon,hv_mw_EdidCommon,hv_mw_DpEdidCommon,hv_mw_VgaEdidCommon}.c` |
| 开机初始化 / 写 RX RAM / HPD | `sdk/MiddleWare/InputPortManager/{HDMI,DisplayPort,VGA}/`，`hv_mw_Hdmi.c:530,2112` |
| DDC 寄存器 / e-seg | `sdk/Driver/HDMI/drv/<chip>/src/hv_drv_HdmiRx.c`、`hv_cal_HdmiRx_UpdateEdidData` |
| Flash 分区大小 | `user/GRHX/<机型>/System/hv_comm_FlashConfig.h` |
| 量产烧录入口 | `user/GRHX/<机型>/DDCCI/src/hv_app_DdcciTPV.c:2957`、`sdk/Common/Debug/LetterShell/src/hv_comm_shell_hdmi_debug.c:150` |
| 打包 / 分区占位 / 提醒 | `user/GRHX/<机型>/build.sh:1328,1476,1601,1793` |
| 全局长度常量 | `sdk/Common/hv_comm_Define.h:58-72` |

## 8. 关联专题
- 相关：`[[panel-porting]]`（换屏必须同步 EDID 的分辨率/刷新率）、`[[board-porting]]`（DDC 端口由板级配置）、`[[flash-storage]]`（EDID 分区与写入策略）、`[[driver-register]]`
