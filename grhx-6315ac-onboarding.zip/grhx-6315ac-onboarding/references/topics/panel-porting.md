# 专题：导入一块新屏参（Panel Porting）

> 定位：换一块新液晶屏时，如何对照屏规格书（Panel Datasheet）把屏参写进工程并编译生效。
> 与 `board-porting.md` 是姊妹篇：主板管"脚"，屏参管"时序 + 接口 + 电气 + 上下电延时"。

## 0. 结论：属于哪一层？
- **user 层（主战场）**：`user/Comm/Panel/PanelList/<屏名>/GR_PanelConfig.h`（屏参本体）、`user/GRHX/<机型>/ProjectConfig/*.h`（选屏）。**新屏适配 90% 改动在这里。**
- **build 构建层（关键枢纽，非五层之一）**：`build.sh` 提取 `GR_PANEL_NAME` 导出为环境变量；`build/compile/common.inc` 用编译器 `-include` 全局强制包含所选屏的头文件，使 `PANEL_xxx` 宏全工程可见。
- **MiddleWare 层**：`sdk/MiddleWare/PanelManager/src/hv_mw_PanelManager.c` 把宏填成 `PanelParam` 结构体，初始化并提供给其它模块；不改。
- **Driver 层**：`sdk/Driver/TX/LvdsTx/`、`DPU/`、`RxBridge/` 等把参数写成硬件寄存器；一般不需改。
- **Boot 层**：不参与屏参。

> 核心机制一句话：**屏参不是"运行时读配置文件"，而是编译期用 `-include` 把某个 `GR_PanelConfig.h` 里的宏全局注入，再由 `PanelManager` 填进结构体。** 换屏 = 换一个被 `-include` 的头文件。

## 1. 屏参文件长什么样（要填哪些字段）
模板：`user/Comm/Panel/PanelList/LVDS_HKC_PN238CT06_1_FHD100_HP/GR_PanelConfig.h`
| 分组 | 宏 | 含义 / 来源（屏规格书） |
|---|---|---|
| 标识 | `PANEL_NAME`、`HV_PANEL_RESOLUTION_TYPE`、`HV_PANEL_INTERFACE_TYPE` | 屏名字符串；FHD/QHD/UHD；LVDSTX/EDPTX/MLVDSTX |
| 时序 | `PANEL_H/V_TOTAL_TYP/MAX/MIN`、`PANEL_H/V_ACTIVE` | 行/场总像素（典型/最大/最小）、有效分辨率 |
| 同步 | `PANEL_H/V_SYNC_WIDTH`、`PANEL_H/V_SYNC_BACK_PORCH` | 同步脉宽、后肩 |
| 时钟/帧率 | `PANEL_PIXEL_CLOCK_TYP/MAX/MIN`(KHz)、`PANEL_FRAME_RATE_TYP/MAX/MIN` | 像素时钟、刷新率（VRR 屏填 Max/Min） |
| 接口 | `PANEL_COLOR_DEPTH`、`PANEL_LANE_NUM`、`PANEL_PORT_NUM`、`PANEL_DATA_FORMAT` | 色深；LVDS pair 数 / port 数；VESA(1)/JEIDA(10) |
| 上下电时序 | `PANEL_DATA_ON_TIME`(T2)、`PANEL_BLK_ON_TIME`(T5)、`PANEL_BLK_OFF_BLACK_DATA_TIME`(T8)、`PANEL_DATA_OFF_TIME`(T6)、`PANEL_POWER_OFF_TIME`(T3)、`PANEL_POWER_OFF_ON_TIME`(T4+T7)、`PANEL_DC_OFF_ON_TIME`、`PANEL_KTX_PLL_LOCK_TIME` | 规格书 Power On/Off Sequence 时序图里的 T1~T8（单位 ms） |
| SSC | `PANEL_SSC_EN/FREQ/FRAC` | 扩频时钟（EMI） |
| PHY MUX | `HV_BOARD_CONFIG_PANEL_PHYx_y_MUX_SEL`、`..._LANEx_PN_SWAP` | TX lane 与芯片 PHY 的映射、PN 翻转（由硬件布线决定） |
| PHY 电气 | `..._SWING_MAIN_CLK/DATA`、`SWING_PRE_*`、`IB_TRIM`、`VCM_ADJ`、`RES_DIFF` | 摆幅/预加重/偏置电流/共模电压/终端电阻（调信号完整性） |

## 2. 详细设定步骤（按顺序执行）

### 步骤 1 — 建屏参目录 + 注册屏 ID
- 在 `user/Comm/Panel/PanelList/` 下新建目录，命名沿用规范：`<接口>_<屏型号>_<分辨率><刷新率>_<客户>`，
  例如 `LVDS_XXX_FHD165_YYY`（目录名即 `GR_PANEL_NAME` 的值）。
- 复制一块**接口/分辨率最接近**的现有屏 `GR_PanelConfig.h` 作模板（比从零写少踩坑）。
- 在 `user/Comm/Panel/PanelList/PanelList.h` 追加一个 ID：
  `#define LVDS_XXX_FHD165_YYY (GR_LVDS_PANEL+18)`（eDP 屏用 `GR_EDP_PANEL+N`）。

### 步骤 2 — 按规格书改写 `GR_PanelConfig.h`
- 逐项对照屏 Datasheet 的 Timing Table 与 Power Sequence 图，填第 1 节的所有宏。
- 关键约束（编译期会 `#error` 拦截，见步骤 6）：`PANEL_H_ACTIVE < PANEL_H_TOTAL_TYP`、`PANEL_PIXEL_CLOCK_MAX <= HV_CHIP_CLK_DATAPATH_MAX`。
- 时序 T2/T5/T6/T3/T4+T7 必须按规格书给足，否则花屏/白屏/背光闪。
- LVDS 的 `PANEL_DATA_FORMAT`（VESA/JEIDA）、`LANE_NUM`、`PORT_NUM`、PN_SWAP 与 PHY MUX 要和硬件走线一致。

### 步骤 3 — 在工程配置里"选中"这块屏
- `user/GRHX/<机型>/ProjectConfig.h` 里 `GR_CUSTOM_PROJECT` 指向一个具体工程配置头文件 `ProjectConfig/<file>.h`。
- 在该 `ProjectConfig/<file>.h` 里写：
  `#define GR_PANEL_NAME  LVDS_XXX_FHD165_YYY`
  （同一文件还并列定义 `GR_BOARD_NAME`、`GR_OSD_NAME`、`GR_KEY_NAME`、`GR_DataBase_NAME`）。
- 该文件的 `HV_PROJECT_CONFIG_PANEL_MODEL` 通常定义为 `GR_PANEL_NAME`（缺省值也在 `user/Comm/ProjectConfig_Default_HT6315x.h`）。

### 步骤 4 — 理解编译期注入（不用改，但必须懂）
- `user/GRHX/<机型>/build.sh` 用 grep 从 `ProjectConfig/<file>.h` 提取并 `export GR_PANEL_NAME`，同时把名字格式化写进 `HV_PROJECT_CONFIG_PANEL_MODEL ?= ...`（property config）。
- `build/compile/common.inc` 里：
  ```
  FILE_INC_CONFIG += -include .../Panel/PanelList/PanelList.h
  FILE_INC_CONFIG += -include .../ProjectConfig/<GR_CUSTOM_PROJECT_FILE>.h
  FILE_INC_CONFIG += -include .../Panel/inc/PanelConfig.h
  FILE_INC_CONFIG += -include .../Panel/PanelList/$(GR_PANEL_NAME)/GR_PanelConfig.h
  ```
  于是所有 `PANEL_xxx` / `HV_BOARD_CONFIG_PANEL_PHYxxx` 宏对全工程可见。
- 所以：**目录名 = `GR_PANEL_NAME` = `PanelList.h` 里的 ID**，三者必须一致，否则 `-include` 找不到文件直接编译失败。

### 步骤 5 — 参数如何落地（消费侧，不用改，但用于定位问题）
- `sdk/MiddleWare/PanelManager/src/hv_mw_PanelManager.c` 的 `static const PanelParam s_stPanelParam = {...}` 用这些宏逐字段填值（第 90 行起）。
- `Hv_Mw_Panel_Init()` → `PanelParamInit()`：默认用静态 `s_stPanelParam`；若 `HV_PROJECT_CONFIG_DYNAMIC_PANEL_EN == ON` 且 FactoryData 里 `bDynamicPanelEn` 有效，则改用 Flash 中 `PanelDataDBRegion.stPanelParam[ucDynamicPanelIndex]`（动态屏参，见第 4 节）。
- 其余模块通过 `Hv_Mw_Panel_GetCurrentPanelParam()` / `Hv_Mw_Panel_GetPanelHactive()` 等取参数；Driver 层 `LvdsTx`/`DPU` 把它写成寄存器。

### 步骤 6 — 编译期校验 + 编译
- `build/BuildCheck/AllConfigCheck.h` 与 `user/Comm/Panel/inc/hv_panel_Param.h` 有 `#error` 校验：
  `HV_PROJECT_CONFIG_PANEL_MODEL != 0`、像素时钟不超芯片上限、Active < Total、Total 在 Min~Max 之间等。
- 跑机型目录下的 `build.sh`（或顶层配置流程）编译，报错就回到步骤 2 改宏。

### 步骤 7 — 配套改动（容易漏）
- **EDID**：`user/Comm/EDID/` 下与屏分辨率/时序/名称相关的 EDID 数据要同步（主机识别到的显示器信息）。
- **工厂信息**：`HV_PROJECT_CONFIG_FACTORY_PANEL_NAME`（如 `"SG270AB04_5"`）在 `ProjectConfig/*.h` 里，工厂菜单显示用。
- **PQ / 画质参数**：部分机型 `hv_comm_PqDef.h` 用 `#if(GR_PANEL_NAME == XXX)` 按屏条件编译画质表，换屏需加分支。
- **OSD 菜单**：分辨率/刷新率相关显示项（如 `hv_app_Function.c`）可能引用屏参宏。
- **背光**：`Hv_Mw_Panel_Init()` 注释明确"初始化参数与背光"，PWM 频率/极性通常在 Board 的 `GR_BoardConfig.h` 或项目配置里。

### 步骤 8 — 上板调试验证
- 点亮后核对：分辨率、刷新率、画面无偏移/雪花/闪屏。
- 花屏/错位 → 优先查 `PANEL_DATA_FORMAT`(VESA/JEIDA)、lane 映射 `PHYx_y_MUX_SEL`、`PN_SWAP`、电气参数 `SWING/VCM/RES_DIFF`。
- 白屏/黑屏/背光闪 → 优先查 T2/T5/T6/T3 上下电时序与 `PANEL_BLK_ON_TIME`。
- 用 `Hv_Mw_Panel_GetCurrentPanelParam()` 打印参数，确认实际生效的是静态还是动态屏参。

## 3. 选中与生效流程（mermaid）

```mermaid
flowchart TD
    A["ProjectConfig.h\nGR_CUSTOM_PROJECT"] --> B["ProjectConfig/<file>.h\nGR_PANEL_NAME = 屏ID"]
    B --> C1["build.sh: grep 出 GR_PANEL_NAME\nexport 成环境变量"]
    C1 --> D["common.inc: -include\nPanelList/$(GR_PANEL_NAME)/GR_PanelConfig.h"]
    D --> E["PANEL_xxx 宏全工程可见"]
    E --> F["PanelManager.c\ns_stPanelParam 填 PanelParam"]
    F --> G["Hv_Mw_Panel_Init → PanelParamInit\n静态 / 动态(Flash)二选一"]
    G --> H["GetCurrentPanelParam → Driver\n(LvdsTx/DPU 写寄存器)"]
    I["AllConfigCheck.h #error 校验"] -.拦截.-> D
    J["build.sh: MODEL_PANELS 选择\n→ property.config\nHV_PROJECT_CONFIG_PANEL_MODEL ?="] -.-> K["仅用于打包命名 / QHD 判定\n不影响屏参编译"]
    style J fill:#fff3cd
    style K fill:#fff3cd
```

## 4. 静态屏参 vs 动态屏参（重要分支）
- **静态（默认）**：屏参编译进 `s_stPanelParam`，换屏必须重新编译固件。绝大多数项目用这个。
- **动态**（`HV_PROJECT_CONFIG_DYNAMIC_PANEL_EN == ON`）：`user/Comm/Panel/src/hv_panel_Param.c` 定义 `s_stDefaultPanelDataDBRegion`，
  内含 `stPanelParam[]` 多套屏参（字段与静态宏一一对应），开机从 Flash 的 `PanelDataDBRegion` 加载，
  由 `FactoryData.bDynamicPanelEn` + `ucDynamicPanelIndex` 选择。适合"一套固件适配多块屏"（产线烧录选择）。
- 若启用动态屏参，新增屏要**同时**在 `hv_panel_Param.c` 的 `stPanelParam[]` 里加一套默认数据（注意 `FLASH_PANLE_PARAM_SUIT_MAX_NUM` 上限）。

## 5. 常见坑点
- **三处一致**：目录名 = `GR_PANEL_NAME` = `PanelList.h` 的 ID 宏名，任何一个不一致都编译失败（`-include` 找不到文件）。
- 忘记在 `PanelList.h` 注册 → `HV_PROJECT_CONFIG_PANEL_MODEL == 0` 触发 `#error`。
- 像素时钟超过芯片 `HV_CHIP_CLK_DATAPATH_MAX`、Active ≥ Total → 编译期报错。
- 换屏只改了屏参头，忘了 EDID / 工厂屏名 / PQ 条件分支 → 主机识别信息或画质不对。
- 动态屏参开启时，改静态 `GR_PanelConfig.h` 可能"看起来没生效"，因为运行时用的是 Flash 里的那套。

## 6. 关键文件速查
| 作用 | 路径 |
|---|---|
| 屏 ID 清单 | `user/Comm/Panel/PanelList/PanelList.h` |
| 屏参本体（改这里最多） | `user/Comm/Panel/PanelList/<GR_PANEL_NAME>/GR_PanelConfig.h` |
| 分辨率/接口类型枚举 | `user/Comm/Panel/inc/PanelConfig.h` |
| 动态屏参默认表 | `user/Comm/Panel/src/hv_panel_Param.c`、`inc/hv_panel_Param.h` |
| 选屏入口 | `user/GRHX/<机型>/ProjectConfig.h` → `ProjectConfig/<file>.h` 的 `GR_PANEL_NAME` |
| 编译期注入 | `build/compile/common.inc`（`-include`）、`user/GRHX/<机型>/build.sh`（export） |
| 编译期校验 | `build/BuildCheck/AllConfigCheck.h` |
| 参数消费 / 初始化 | `sdk/MiddleWare/PanelManager/src/hv_mw_PanelManager.c` |
| 驱动落地 | `sdk/Driver/TX/LvdsTx/`、`sdk/Driver/DPU/` |
| 配套 | `user/Comm/EDID/`、各机型 `hv_comm_PqDef.h`、`HV_PROJECT_CONFIG_FACTORY_PANEL_NAME` |

## 7. 新增/切换屏后的验证清单（实操总结）

### 7.1 新增一块屏的最小改动集（4 项）
1. 新建目录 `user/Comm/Panel/PanelList/<新屏名>/GR_PanelConfig.h`（复制同型号最接近的屏作模板）。
2. 修 3 处标识：`PANEL_NAME`、include guard、`@file` / `@brief`。
   **务必检查模板的 guard 是否残留别的屏名**——若两屏 guard 相同，同时被 include 时后者会被跳过。
3. 在 `PanelList.h` 追加 ID，用该段下一个可用编号（LVDS 用 `GR_LVDS_PANEL+N`，eDP 用 `GR_EDP_PANEL+N`，两段独立）。
4. 保持所有硬件宏与模板一致（用归一化 diff 验证），仅改标识。

### 7.2 切换工程前的 3 项前置核对
- **当前生效工程**：看机型目录 `ProjectConfig.h` 的 `GR_CUSTOM_PROJECT`，再打开 `ProjectConfig/<该值>.h` 看 `GR_PANEL_NAME`。
  `out/.config` 可能不存在（顶层 `project_config.sh` 未跑），此时以 `out/` 里**最新编译产物**的文件名判断实际编译的是哪个机型。
- **板卡匹配**：新屏参的 `PHYx_y_MUX_SEL` / `PN_SWAP` / 电气参数是按某块板走线配的，跨板卡套用可能点不亮。切换前确认 `GR_BOARD_NAME` 与来源屏一致。
- **名称长度**：`PANEL_NAME` 写入 `ucPanelName[HV_PANEL_NAME_BYTE_MAX]`（`hv_comm_Define.h`，当前 40 字节）。
  含 `\0` 不得超过 40，长客户后缀容易越界。

### 7.3 切换后的端到端验证（无需编译即可查）
在机型目录下模拟 `build.sh` 的提取逻辑：
```bash
CUSTOM=$(grep -oP '#define\s+GR_CUSTOM_PROJECT\s+\K\w+' ProjectConfig.h | head -1)
PANEL=$(grep -oP '#define\s+GR_PANEL_NAME\s+\K\w+' ProjectConfig/$CUSTOM.h | head -1)
ls -l <ROOT>/user/Comm/Panel/PanelList/$PANEL/GR_PanelConfig.h   # -include 目标必须存在
grep -n "$PANEL" <ROOT>/user/Comm/Panel/PanelList/PanelList.h      # ID 必须已注册
```
四点须全部通过：三处名字一致、目录存在、ID 已注册、`PANEL_NAME` 未超长。
再把 `common.inc` 的 `-include` 路径代入确认，即可判定编译期注入不会失败。

### 7.4 两条独立链路（最容易混淆）
| 链路 | 来源 | 影响 |
|---|---|---|
| 屏参编译 | `GR_PANEL_NAME`（`ProjectConfig/*.h`）→ `build.sh` export → `common.inc -include` | 决定编译进哪套屏参，**真正决定屏能否点亮** |
| 打包命名 | `MODEL_PANELS` 交互选择 → `property.config` 的 `HV_PROJECT_CONFIG_PANEL_MODEL ?=` → `SIMPLE_PANEL_NAME` | 只影响 bin 文件名 / QHD 判定，**不影响屏参** |

`SIMPLE_PANEL_NAME` 由 `awk -F'_'` 取第 3、4 段（如 `LVDS_SG2701B08_1_V7_1_...` → `1_V7`），
所以只换客户后缀时打包名不变；看到 bin 文件名没变**不代表屏参没生效**。

### 7.5 回退
改 `GR_PANEL_NAME` 时把旧值保留在行尾注释（工程现有风格即如此），回退只需换回宏名并重新编译。
屏参是编译期注入的，**任何切换都必须重新编译固件**，仅改文件不生效。

## 8. 关联专题
- 相关：`[[board-porting]]`（屏的 PHY MUX/PN_SWAP 与主板走线强相关）、`[[driver-register]]`、`[[power-channel-manager]]`
