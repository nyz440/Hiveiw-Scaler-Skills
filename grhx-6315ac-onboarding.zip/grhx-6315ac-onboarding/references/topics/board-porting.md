# 专题：新主板 PIN 脚适配（Board Porting）

> 定位：导入一块新主板时，如何对照硬件原理图把芯片 PIN 脚配成所需功能。
> 这是**板级适配（Porting）**工作，改动最集中的地方在 `user/` 板级目录。

## 0. 结论：属于哪一层？
PIN 脚设定横跨三层，但**核心改动在 user 层**：
- **user 层（板级）** — 主力：`user/Comm/Board/GR_XXX/GR_BoardConfig.h` 定义"功能→芯片脚号"映射；`Pinshare/` 定义引脚复用（PinMux）寄存器配置。**新主板适配 90% 的改动在这里。**
- **Driver 层** — 提供能力：`sdk/Driver/.../hv_drv_Gpio.c`（GPIO/PinMux 驱动）+ `sdk/Driver/Arch/ht6315x/regs_offset/HV_BASE_SYS.h`、`HV_PAGE_HT6315x_SH06_TOP.h`（引脚复用寄存器地址定义），对外提供 `HV_R32/HV_W32` 寄存器读写。
- **MiddleWare 层** — 编排：`Hv_Mw_System_Init()` 调用 `Hv_Cal_Pinshare_Init()` 把复用配置落实、调用 GPIO 驱动初始化。
- **Boot 层** — 一般**不直接参与** PIN 设定（Boot 只做栈/时钟/跳 main）；极早期复用若需要才在 Boot 阶段配。

## 1. 详细看代码步骤（按此顺序改/读）

### 步骤 1 — 选/建板级目录并注册
- 所有主板集中在 `user/Comm/Board/`，每个主板一个目录（如 `GR_HG201/`）。
- 先到 `user/Comm/Board/BoardList.h` 给新主板分配一个 ID（如 `GR_XXX (GR_6315A_BOARD+N)`）。
- 复制一个相近的现有主板目录作为模板（保留 `GR_BoardConfig.h`、`Pinshare/`、`.mk`）。

### 步骤 2 — 编辑 `GR_BoardConfig.h`（功能→脚号映射）
这是"对照原理图"最直接的文件，关键定义：
- 芯片封装：`HV_BOARD_CONFIG_CHIP_PACKAGE_TYPE`（PIN68 / PIN88 / PIN128 等），决定可用脚范围。
- 功能脚号：一组 `HV_BOARD_CONFIG_GPIO_xxx`（如 `HV_BOARD_CONFIG_GPIO_PANEL_EN (52)`、`HV_BOARD_CONFIG_GPIO_POWERKEY (55)`）。括号内是**芯片 PIN 脚号**。
- 端口使能：`HV_BOARD_CONFIG_HDMI_x` / `VGA` / `DISPLAYPORT` 用 `PORT_VALID/PORT_INVALID` 开关。
- 外设脚：EEPROM/I2C 的 SCL/SDA、`WP` 脚；LED/PWM 极性；音频 PA 静音/关断脚。
- 注意：`0xFF` 表示该引脚**未使用**（如某 HDMI 的 DDC 未接就填 `0xFF`）。这些宏大多用 `#ifndef` 包裹，允许在更上层（ProjectConfig/机型）被覆盖。

### 步骤 3 — 编辑 `Pinshare/`（引脚复用 PinMux）
一个物理脚往往有多功能（如 `PIN52/GPIO29/Panel_EN/UART0_TX/I2CM0_SDA/DBG_SPICLK`），
必须明确"配成哪个功能"：
- 源文件：`Pinshare/hv_cal_Pinshare.xml`（工具源）+ 生成的 `hv_cal_Pinshare.c`。
- 生成代码里有一个 `const static UINT32 PinshareArray[][4] = {{寄存器地址, 位起, 位止, 值}, ...}`，
  每一项对应一个引脚的 `reg_xxx_func_sel`（功能选择）/`pin_sel`（脚选择）/`io_ctrl`（IO 控制）。
- 例：`{0x110b882c, 22, 23, 0x1},//reg_pwr_on_func_sel` 把 PWR_ON 脚的功能选为某功能。
- 实际做法：用原厂 PinMux 工具导入 `.xml` 改复用关系后重新生成 `.c`；或手工改数组。
- **必须保证**：`BoardConfig.h` 里某个脚"被用作 PANEL_EN"，与 `Pinshare` 里该脚的功能选择一致，否则功能不工作。

### 步骤 4 — 改具体外设配置，引用 Board 的脚号
各外设模块消费 `BoardConfig` 的宏，例如：
- `user/GRHX/HT6315A_DEMO_1A1H/Keypad/Inc/KeyboardConfig.h`：按键用 `E_ADC_CHNx`（ADC 通道）或 `GPIO_KEYx_PIN`（默认 `0xFF`=未用），脚号来自 BoardConfig。
- 其他外设（LED/LCD/EEPROM 驱动）同理通过 `HV_BOARD_CONFIG_GPIO_xxx` 拿到脚号。

### 步骤 5 — 选择该 Board 并编译
- 通过 `build/project_config.sh` 或 `ProjectConfig.h` 选定新 Board（宏/参数指向 `GR_XXX`）。
- 编译；`Pinshare/` 的 `.mk` 会把它编进工程。

### 步骤 6 — 板级调试验证
- 用 `HV_R32(复用寄存器地址)` 读回 `PinshareArray` 配的值，核对是否写对。
- 用万用表/示波器量板子对应脚，确认电平/功能符合预期（如 PANEL_EN 能拉高点亮屏）。

## 2. 数据流 / 配置落地流程（mermaid）

```mermaid
flowchart TD
    A[硬件原理图: 标出芯片 PIN 脚连接] --> B["GR_BoardConfig.h\n定义 HV_BOARD_CONFIG_GPIO_xxx = 脚号"]
    A --> C["Pinshare/*.xml + .c\nPinshareArray: 脚→func_sel/pin_sel/io_ctrl"]
    B --> D["Hv_Mw_System_Init()"]
    C --> D
    D --> E["Hv_Cal_Pinshare_Init()\n(HV_W32 写复用寄存器)"]
    D --> F["GPIO 驱动初始化"]
    E --> G["物理脚配成指定功能"]
    F --> G
    G --> H["外设模块(Keypad/LED/EEPROM…)\n按 BoardConfig 脚号工作"]
```

## 3. 常见坑点 / 注意
- **双重编号**：`PINxx`（物理脚号）与 `GPIOyy`（逻辑 GPIO 编号）不同。`BoardConfig.h` 用的是**芯片 PIN 号**，`Pinshare` 也按 PIN 配复用；别把两者混用。
- **复用一致性**：`BoardConfig` 说"此脚当 PANEL_EN"，`Pinshare` 必须把它配成对应功能，二者冲突是主板点不亮最常见原因。
- **`0xFF` = 未使用**：某功能在某板不接，就填 `0xFF`，相关代码会跳过。
- **封装类型**：`PIN68/88/128` 决定哪些脚存在，选错封装会引用不存在的脚。
- **覆盖机制**：大量宏用 `#ifndef` 包裹，可在机型/ProjectConfig 层覆盖 Board 默认值，改之前先搜是否已被上层重定义。

## 4. 关键文件速查
| 作用 | 路径 |
|---|---|
| 主板清单/ID 注册 | `user/Comm/Board/BoardList.h` |
| 板级脚号映射（改这里最多） | `user/Comm/Board/GR_XXX/GR_BoardConfig.h` |
| 引脚复用配置（工具源/生成） | `user/Comm/Board/GR_XXX/Pinshare/hv_cal_Pinshare.{xml,c}` |
| 复用初始化入口 | `user/Comm/Board/GR_XXX/Pinshare/inc/hv_cal_Pinshare.h` → `Hv_Cal_Pinshare_Init()` |
| GPIO/PinMux 驱动 | `sdk/Driver/Peripheral/drv/src/hv_drv_Gpio.c` |
| 复用寄存器地址定义 | `sdk/Driver/Arch/ht6315x/regs_offset/HV_BASE_SYS.h`、`HV_PAGE_HT6315x_SH06_TOP.h` |
| 初始化编排 | `sdk/MiddleWare/RunTime/SystemTask/src/hv_mw_SystemManager.c`（`Hv_Mw_System_Init`） |
| 外设消费脚号示例 | `user/GRHX/HT6315A_DEMO_1A1H/Keypad/Inc/KeyboardConfig.h` |

## 5. 关联专题
- 相关：`[[driver-register]]`（寄存器读写 API）、`[[power-channel-manager]]`（PWR_ON/PWR_KEY 脚如何参与待机）、`[[osd-menu]]`
