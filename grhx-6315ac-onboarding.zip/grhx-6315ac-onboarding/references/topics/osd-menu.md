# 专题：OSD 菜单数据流（扩展中）

> 定位：用户可见的屏上菜单，是最大的客户定制模块（`user/GRHX/.../OSD/` 占大量代码）。
> 阅读顺序参见 `references/code-reading-path.md` 第 8 步。

## 1. 涉及的关键文件（待补充完整路径）
- `user/GRHX/HT6315A_DEMO_1A1H/OSD/<OSD_NAME>/Behaviour/src/hv_app_Osd.c` — OSD 主行为
- `user/GRHX/HT6315A_DEMO_1A1H/OSD/<OSD_NAME>/Behaviour/src/hv_app_OsdMenu.c` — 菜单状态机
- `user/GRHX/HT6315A_DEMO_1A1H/OSD/<OSD_NAME>/` 下的资源（`.bin` 字库/图标，由工具生成）

## 2. 核心概念 / 数据流（待填）
- 触发：`OSD 事件 → OsdQueue → Hv_Mw_OsdRun → 菜单状态机 → 屏幕绘制`
- 待填：菜单树结构、OSD 资源（bin）如何加载、按键如何驱动菜单、OSD 与 Database 的联动（改设置即时 `HV_COMMON_DATABASE_SET`）。

## 3. 关键函数入口（待填）
| 函数名 | 文件 | 作用 |
|--------|------|------|
| `Hv_Mw_Osd_TaskStartInit` | MiddleWare/OSD | OSD 任务初始化 |
| `Hv_Mw_OsdRun` | MiddleWare/OSD | OSD 事件处理入口 |

## 4. 常见坑点 / 注意（待填）
- OSD 资源 `.bin` 由 `tools/osd_tool` 生成，改 UI 通常要重新生成资源。
- 不同机型用不同 `OSD_xxx` 子目录（见 `ProjectConfig.h` 的 `GR_OSD_NAME`）。

## 5. 关联专题
- 相关：`[[driver-register]]`、`[[power-channel-manager]]`
