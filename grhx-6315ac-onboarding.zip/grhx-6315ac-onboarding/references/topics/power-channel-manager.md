# 专题：电源 / 通道管理器（扩展中）

> 定位：PowerManager（待机/唤醒/断电）与 ChannelManager/InputPortManager（信号检测与通道切换）的业务逻辑。

## 1. 涉及的关键文件（待补充完整路径）
- `sdk/MiddleWare/PowerManager/src/hv_mw_PowerManager.c` — 电源状态机
- `sdk/MiddleWare/ChannelManager/` — 通道管理
- `sdk/MiddleWare/InputPortManager/` — 输入口（HDMI/VGA/DP）管理
- `user/GRHX/.../System/EventHub/src/hv_mw_EventHub.c` — 事件中心（跨模块事件聚合）

## 2. 核心概念 / 数据流（待填）
- 电源：`Power事件 → PowerQueue → Hv_Mw_Power_SystemQueueMsgProc`（待机/唤醒/断电）。
- 通道切换：输入信号检测 → 通道切换 → 画面输出，涉及 PMU 判定 AC/DC 上电。
- EventHub：聚合各模块事件，统一分发（具体实现待读 `hv_mw_EventHub.c` 确认）。

## 3. 关键函数入口（待填）
| 函数名 | 文件 | 作用 |
|--------|------|------|
| `Hv_Mw_Power_ManagerInit` | PowerManager | 电源管理初始化 |
| `Hv_Mw_Channel_Manager_Init` | ChannelManager | 通道管理初始化 |
| `Hv_Mw_EventHub_TaskStartInit` | EventHub | 事件中心初始化 |

## 4. 常见坑点 / 注意（待填）
- 待机/唤醒流程对"尽快亮灯""上次关机原因"敏感（见 `SystemManager.c` 中 LED 与 `bPowerOff` 判定）。
- 断电保护依赖看门狗（`HV_PROJECT_CONFIG_FEED_WATCHDOG_TIME`）。

## 5. 关联专题
- 相关：`[[driver-register]]`、`[[osd-menu]]`
