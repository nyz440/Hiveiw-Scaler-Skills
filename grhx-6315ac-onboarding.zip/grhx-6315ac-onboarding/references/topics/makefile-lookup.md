# 专题：GNU make 如何查找 Makefile（含本项目落地）

> 定位：回答「直接敲 `make` 时到底读了哪个文件」「自定义名字为什么不被识别」「本项目该在哪一层敲 `make`」。
> 是编译链 `build.sh → make → include → Makefile.mk` 的前置知识，配合 `[[build-folders]]` 阅读。

## 1. 涉及的关键文件（本项目对照）

| 文件 | 角色 | 会被默认查找到吗 |
|---|---|---|
| `Makefile`（项目根） | 转发壳，仅一行 `include build/Makefile` | 会（在根目录执行时） |
| `build/Makefile` | 真正的主 makefile：路径变量、库清单、`PRE_CHECK`、debug/release/gdb 目标 | 会（在 `build/` 下执行时） |
| `build/Makefile.mk` | 链接阶段分片，自定义文件名 | 不会，靠 `-f` 显式指定 |
| `build/compile/*.inc` | 由 `build/Makefile` 用 `include` 引入 | 不会，靠 `include` |
| `sdk/Makefile.mk`、`user/Makefile.mk`、各子目录 `Makefile.mk` | 递归调度的分片 | 不会，靠 `include` |
| `user/GRHX/<机型>/build.sh` | 切到 build 目录后裸跑 `make clean` / `make <debug\|release> -j` | — |

## 2. 核心规则：三个精确名字 + 固定优先级

`make` 不带 `-f` 时，在**当前工作目录**按固定列表逐个做文件名精确匹配，命中第一个即停止，其余忽略：

1. `GNUmakefile`
2. `makefile`
3. `Makefile`

| 判定 | 结论 |
|---|---|
| 匹配方式 | 文件名必须精确等于三者之一；无模糊、无前缀、无扩展名通配（`Makefile.mk` 不算） |
| 多个同时存在 | 取优先级最高的一个，其余完全不读 |
| 大小写 | 敏感，`Makefile` 与 `makefile` 是两个不同文件（Linux 文件系统下；大小写不敏感的文件系统上二者无法共存） |
| `-f` 指定后 | 不再做默认查找，只读指定文件 |
| `-C <dir>` | 先切换目录再查找，查找基准随之改变 |
| `-I <dir>` | 只影响 `include` 的搜索路径，**不影响**主 makefile 的查找 |
| `MAKEFILES` 环境变量 | 可让 make 额外先读指定 makefile，本项目未使用 |

实测：同目录同时放三个文件，`make` 输出 `FROM_GNUmakefile`，验证优先级。

## 3. 自定义文件名：必须用 `-f`

`make1`、`build.mk`、`rules.mk`、`Makefile.mk` 都不在默认列表中：

```bash
make -f make1
make --file=make1
make --makefile=make1
make -f -            # 从标准输入读取
```

目录中只有 `make1` 而无默认三文件时，直接执行 `make` 的实测报错为：

```
make: *** No targets specified and no makefile found.  Stop.
```

注意 `No rule to make target 'xxx'` 是另一类错误（指定了目标但该目标没有规则），不要混淆。

### 同时指定多个 `-f`

```bash
make -f a.mk -f b.mk
```

按顺序依次读取并合并，实测边界：

| 情形 | 结果 |
|---|---|
| 变量 `X=one` → `X=two` | 后者覆盖，得 `two` |
| 变量 `X?=one` → `X?=two` | 前者保留，得 `one` |
| 两处都定义了同一 target 的 recipe | 报 `warning: overriding recipe for target 'all'`，后者生效 |
| 默认目标 | 取**第一个** `-f` 文件的首个 target |
| 命令行 `make X=three` | 命令行变量优先级最高，覆盖文件内赋值（除非用 `override`） |

## 4. 排查：确认 make 实际读了哪个文件

```bash
ls -la | grep -i make                        # 先确认真实文件名与大小写
make -d 2>&1 | grep 'Reading makefile'       # 输出 Reading makefile 'Makefile'...
make -pn | less                              # 打印展开后的数据库，核对变量
```

`make -n`（`--dry-run`）只打印将执行的命令，**不会**显示读入的 makefile，不能用来判断查找结果。
`build-folders.md` 里的 `make -pn release | grep -E '^OBJ_...'` 正是这个数据库的用法。

## 5. 本项目落地与常见坑

- **必须在 `build/` 目录跑 `make`**：`build.sh` 的 `cmake_project()` 先 `cd $BUILD_PROJECT_PATH`，再裸跑
  `make clean` / `make $DEBUG_VERSION -j`，靠默认查找命中 `build/Makefile`。
  而 `build/Makefile` 里 `ROOT_DIR = $(shell pwd)/..`，在项目根裸跑会把根路径算错。
- **`build/Makefile.mk` 是 `-f` 的真实用例**：`build/Makefile` 的 debug/release/gdb 目标里用
  `$(MAKE) <目标> -C "$(BUILD_OUT_OBJ_DIR)" -f $(BUILD_DIR)/Makefile.mk`，同时演示了 `-C` 与 `-f`。
- **`include` 不等于默认查找**：`build/Makefile:65-68` 引入 `out/.config` 与 `build/compile/*.inc`；
  文件名再像 `Makefile` 的 `.inc` / `Makefile.mk` 也不会被自动识别。
- **调试 `build.sh` 的小技巧**：在脚本里临时插入
  `echo "CHECK_POINT_01 按任意键继续..." && read -n1` 作断点，逐段确认执行到了哪一步
  （`build.sh` 里原本就有被注释的同类写法 `# echo "按任意键继续..." && read -n1`）。
  注意 `read -n1` 会阻塞，自动化 / 无人值守编译前要删掉。

## 6. 一句话记忆

`make` 只认 `GNUmakefile` → `makefile` → `Makefile` 三个精确名字；`Makefile.mk` 这类自定义文件
只能靠 `-f`（本项目还要配合 `-C`）显式指定。

## 7. 关联专题

- 相关：`[[build-folders]]`（编译目录清单与 `make -pn` 核对法）、`[[architecture]]`（配置与编译阶段）、
  `[[cheatsheet]]`（关键文件速查）
